# The Last Road — Visual Pass 4

## Changes made in the live Kotlin Canvas renderer
- Added gait-synchronized arm swing for Ali during walking, running, and pushing.
- Added gait-synchronized arm swing for Walaa during walking and running.
- Added subtle idle arm/breathing sway to avoid fully static silhouettes.
- Added a small near-camera rain layer with thicker streaks to improve perceived depth.

## Limits
- These remain procedural Canvas characters; this pass does not claim to add raster sprite sheets.
- Sprite-sheet production/integration is still a separate milestone and requires consistent transparent frame assets.
- Android Gradle build and device testing were not run in this environment.
