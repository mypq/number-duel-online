# Pass 9 — Gameplay logic patch

Changes made in this pass:
- Added three crouch-cover zones aligned with the roadside wreckage at approximately X=1850, 2325 and 2775. Crouching in these zones suppresses monster detection/search reacquisition and can break a chase.
- Running now produces a longer detection radius, so sprinting is a meaningful risk instead of being treated like normal walking.
- Increased monster chase speed from 118 to 245 world units/second. It should pressure the player more consistently, while the sprint remains faster.
- Improved chase break conditions when cover is reached.
- Fixed interaction prompt state updates so Compose state is only changed when the prompt or availability actually changes, reducing unnecessary recompositions during active gameplay.
- The caught/recovery feedback flag clears after the player moves away from the checkpoint.

Limitations / verification:
- This is still a first-chapter prototype; cover is represented by simple world-X zones, not pixel-perfect line-of-sight or full hiding animations.
- No Android Gradle build or on-device performance test was run in this environment. Please build the ZIP using your APK site and report any build errors or gameplay issues.
