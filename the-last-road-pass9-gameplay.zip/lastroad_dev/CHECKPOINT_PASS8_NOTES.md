# The Last Road — Pass 8: Story Milestones & Checkpoint Recovery

## Implemented
- Added two persistent safe milestones on the exposed road (around world X 1700 and 2500).
- Story milestone activation stores the checkpoint position and progress index in SharedPreferences.
- Monster catch recovery now returns the active protagonist and companion to the last saved safe stretch, rather than always teleporting to a hard-coded location.
- Recovery resets both characters' vertical/horizontal velocity and grounded state to reduce fall-through/airborne edge cases.
- Existing first-chapter dialogue and objective beats are preserved.

## Verification
- Source changes are packaged in this archive.
- Android Gradle build and device testing have not been run in this environment; do not treat this pass as APK/device verified.
- This is a checkpoint/progression improvement for the existing first chapter, not a complete implementation of all five chapters.
