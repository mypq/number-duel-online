# Gameplay Pass 7 — First Stealth/Monster Loop

## Implemented in source
- Added engine-owned monster states: PATROL, INVESTIGATE, CHASE, SEARCH, RETURN.
- Creature position is now updated by gameplay logic and passed to the renderer, rather than remaining a fixed atmospheric prop.
- Approaching the exposed road can trigger investigation; being too close or running within detection range triggers chase.
- Crouching reduces detection range and can help break the chase at a greater distance.
- The creature searches briefly after losing the player, then returns to its starting area.
- Added a non-lethal caught/checkpoint recovery so players can continue testing the opening loop.
- Added Arabic dialogue and objective updates for the first chase sequence.

## Verification status
- Source changes were reviewed for wiring between GameEngine, GameScreen, and GameRenderer.
- Android Gradle build/device test was not run; the environment does not include the Gradle wrapper JAR or Android SDK setup. Import and build in Android Studio before treating this as device-verified.
- This is the first stealth loop only, not a completed full game or all five chapters.
