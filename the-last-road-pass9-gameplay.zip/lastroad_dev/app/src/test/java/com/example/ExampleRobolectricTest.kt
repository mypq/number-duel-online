package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.game.camera.Camera2D
import com.example.game.core.GameEngine
import com.example.game.core.GameScreenState
import com.example.game.model.CharacterId
import com.example.game.model.MovementState
import com.example.game.model.Player
import com.example.game.model.Vector2
import com.example.game.model.World
import com.example.game.physics.PhysicsSystem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context matches The Last Road`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("The Last Road", appName)
    }

    @Test
    fun `game opens at main menu with both protagonists in story`() {
        val engine = GameEngine()
        assertEquals(GameScreenState.MAIN_MENU, engine.screenState)

        // Starting a new game starts with BOTH Ali and Walaa
        engine.startNewGame()
        assertEquals(GameScreenState.PLAYING, engine.screenState)
        assertNotNull(engine.ali)
        assertNotNull(engine.walaa)
        assertEquals(CharacterId.ALI, engine.ali.characterId)
        assertEquals(CharacterId.WALAA, engine.walaa.characterId)
        // Both are located beside their broken vehicle
        assertTrue(engine.ali.position.x > 100f && engine.ali.position.x < 300f)
        assertTrue(engine.walaa.position.x > 100f && engine.walaa.position.x < 300f)
    }

    @Test
    fun `in-game character switching transfers control smoothly`() {
        val engine = GameEngine()
        engine.startNewGame()

        // Initially controlling Ali
        assertEquals(CharacterId.ALI, engine.activeCharacterId)
        assertEquals(CharacterId.ALI, engine.activePlayer.characterId)
        assertEquals(CharacterId.WALAA, engine.companionPlayer.characterId)

        val aliInitialX = engine.ali.position.x
        val walaaInitialX = engine.walaa.position.x

        // Switch to Walaa
        engine.switchActiveCharacter()
        assertEquals(CharacterId.WALAA, engine.activeCharacterId)
        assertEquals(CharacterId.WALAA, engine.activePlayer.characterId)
        assertEquals(CharacterId.ALI, engine.companionPlayer.characterId)

        // Verify neither character was deleted or teleported
        assertEquals(aliInitialX, engine.ali.position.x, 0.01f)
        assertEquals(walaaInitialX, engine.walaa.position.x, 0.01f)

        // Switch back to Ali
        engine.switchActiveCharacter()
        assertEquals(CharacterId.ALI, engine.activeCharacterId)
    }

    @Test
    fun `ali can push heavy crate while walaa cannot`() {
        val physics = PhysicsSystem()
        val world = World()

        val ali = Player(
            characterId = CharacterId.ALI,
            position = Vector2(world.heavyCrate.x - 38f, 700f),
            isGrounded = true
        )
        val initialCrateX = world.heavyCrate.x

        // 1. Ali pushes right into the heavy crate
        physics.update(
            player = ali,
            world = world,
            dt = 0.5f,
            moveInput = 1.0f,
            jumpTriggered = false,
            crouchInput = false,
            runInput = false
        )

        assertTrue("Ali's physical strength should push the crate forward", world.heavyCrate.x > initialCrateX)
        assertEquals(MovementState.PUSHING, ali.state)

        // 2. Walaa tries to push a heavy crate
        val currentCrateX = world.heavyCrate.x
        val walaa = Player(
            characterId = CharacterId.WALAA,
            position = Vector2(currentCrateX - 32f, 700f),
            isGrounded = true
        )

        val feedback = physics.update(
            player = walaa,
            world = world,
            dt = 0.5f,
            moveInput = 1.0f,
            jumpTriggered = false,
            crouchInput = false,
            runInput = false
        )

        assertEquals("Crate position should not move when Walaa pushes alone", currentCrateX, world.heavyCrate.x, 0.01f)
        assertTrue(feedback != null && feedback.contains("الصندوق ثقيل"))
    }

    @Test
    fun `walaa can crawl through narrow low duct while ali is blocked`() {
        val physics = PhysicsSystem()
        val world = World()
        val duct = world.narrowDuct

        // 1. Ali tries to walk through narrow duct on the high catwalk
        val ali = Player(
            characterId = CharacterId.ALI,
            position = Vector2(duct.left - 38f, duct.floorY),
            isGrounded = true
        )

        val aliFeedback = physics.update(
            player = ali,
            world = world,
            dt = 0.2f,
            moveInput = 1.0f,
            jumpTriggered = false,
            crouchInput = true,
            runInput = false
        )

        assertTrue("Ali should be blocked before entering the narrow duct", ali.position.x <= duct.left)
        assertTrue(aliFeedback != null && aliFeedback.contains("الممر منخفض وضيق"))

        // 2. Walaa crawls through the narrow duct
        val walaa = Player(
            characterId = CharacterId.WALAA,
            position = Vector2(duct.left - 10f, duct.floorY),
            isGrounded = true
        )

        for (i in 1..20) {
            physics.update(
                player = walaa,
                world = world,
                dt = 0.03f,
                moveInput = 1.0f,
                jumpTriggered = false,
                crouchInput = true,
                runInput = false
            )
        }

        assertTrue("Walaa should enter and crawl through the duct", walaa.position.x > duct.left)
        assertTrue(walaa.isCrouching)
    }

    @Test
    fun `full cooperative puzzle walkthrough without teleportation or cheats`() {
        val engine = GameEngine()
        engine.startNewGame()

        val world = engine.world
        val physics = engine.physics

        // --- STEP 1: Ali pushes the heavy crate to the target slot ---
        assertEquals(CharacterId.ALI, engine.activeCharacterId)
        engine.ali.position.set(880f, 700f)
        engine.ali.isGrounded = true

        val initialCrateX = world.heavyCrate.x
        while (world.heavyCrate.x < world.heavyCrate.targetSlotX) {
            physics.update(
                player = engine.ali,
                world = world,
                dt = 0.02f,
                moveInput = 1.0f,
                jumpTriggered = false,
                crouchInput = false,
                runInput = false
            )
        }
        assertTrue("Crate should be moved forward by Ali", world.heavyCrate.x > initialCrateX)
        assertTrue("Crate is placed under ledge", world.heavyCrate.isPlacedUnderLedge)
        assertEquals(1040f, world.heavyCrate.x, 0.1f)

        // --- STEP 2: Switch to Walaa ---
        engine.switchActiveCharacter()
        assertEquals(CharacterId.WALAA, engine.activeCharacterId)

        // Position Walaa in front of crate (at 990f, ground 700f)
        engine.walaa.position.set(990f, 700f)
        engine.walaa.isGrounded = true

        // Walaa jumps onto crate top (crate is at 1040f..1105f, y = 635f)
        physics.update(engine.walaa, world, 0.016f, moveInput = 1.0f, jumpTriggered = true, crouchInput = false, runInput = false)
        var jumpTicks = 0
        while (!engine.walaa.isGrounded && jumpTicks < 50) {
            val move = if (engine.walaa.position.x < 1055f) 1.0f else 0.0f
            physics.update(engine.walaa, world, 0.016f, moveInput = move, jumpTriggered = false, crouchInput = false, runInput = false)
            jumpTicks++
        }
        assertEquals("Walaa lands on crate top at 635f", 635f, engine.walaa.position.y, 1.0f)
        assertTrue("Walaa is on top of crate horizontally", engine.walaa.position.x + engine.walaa.width >= world.heavyCrate.x && engine.walaa.position.x <= world.heavyCrate.x + world.heavyCrate.width)

        // Walaa jumps from crate (635f) onto scaffolding step (1080f..1150f, y = 570f)
        physics.update(engine.walaa, world, 0.016f, moveInput = 1.0f, jumpTriggered = true, crouchInput = false, runInput = false)
        jumpTicks = 0
        while (!engine.walaa.isGrounded && jumpTicks < 50) {
            val move = if (engine.walaa.position.x < 1105f) 1.0f else 0.0f
            physics.update(engine.walaa, world, 0.016f, moveInput = move, jumpTriggered = false, crouchInput = false, runInput = false)
            jumpTicks++
        }
        assertEquals("Walaa lands on scaffolding step at 570f", 570f, engine.walaa.position.y, 1.0f)

        // Walaa jumps from scaffolding step (570f) onto catwalk (1140f..1500f, y = 520f)
        physics.update(engine.walaa, world, 0.016f, moveInput = 1.0f, jumpTriggered = true, crouchInput = false, runInput = false)
        jumpTicks = 0
        while (!engine.walaa.isGrounded && jumpTicks < 50) {
            val move = if (engine.walaa.position.x < 1160f) 1.0f else 0.0f
            physics.update(engine.walaa, world, 0.016f, moveInput = move, jumpTriggered = false, crouchInput = false, runInput = false)
            jumpTicks++
        }
        assertEquals("Walaa lands on catwalk at 520f", 520f, engine.walaa.position.y, 1.0f)

        // Walaa crawls through duct (1200f..1380f) to the lever
        while (engine.walaa.position.x < world.gateLever.x - 15f) {
            physics.update(engine.walaa, world, 0.016f, moveInput = 1.0f, jumpTriggered = false, crouchInput = true, runInput = false)
        }
        assertEquals(520f, engine.walaa.position.y, 1.0f)
        assertTrue("Walaa has reached near the gate lever", world.gateLever.isNear(engine.walaa.position.x, engine.walaa.position.y))

        // --- STEP 3: Activate the lever ---
        assertFalse(world.gateLever.isActivated)
        assertFalse(world.securityGate.isOpen)

        engine.tick(0.016f)
        assertTrue("Interaction prompt should become available", engine.isInteractionAvailable)

        engine.triggerInteraction()
        assertTrue("Lever must be activated", world.gateLever.isActivated)
        assertTrue("Security gate must be open", world.securityGate.isOpen)

        // --- STEP 4: Switch to Ali and verify Ali can pass through the gate on the road ---
        engine.switchActiveCharacter()
        assertEquals(CharacterId.ALI, engine.activeCharacterId)

        engine.ali.position.set(1220f, 700f) // Before the gate on ground
        engine.ali.isGrounded = true

        // Ali walks forward past the gate (x = 1260f)
        for (i in 1..30) {
            physics.update(engine.ali, world, 0.016f, moveInput = 1.0f, jumpTriggered = false, crouchInput = false, runInput = false)
        }
        assertTrue("Ali must now be able to pass through the opened gate on ground", engine.ali.position.x > world.securityGate.x + 30f)

        // --- STEP 5: Reset / Restart level and verify puzzle can be solved again ---
        engine.startNewGame()
        assertFalse("Lever should be reset", world.gateLever.isActivated)
        assertFalse("Gate should be reset to closed", world.securityGate.isOpen)
        assertEquals(920f, world.heavyCrate.x, 0.1f)
    }

    @Test
    fun `jumping on the road cannot bypass closed security gate`() {
        val physics = PhysicsSystem()
        val world = World()

        assertFalse(world.securityGate.isOpen)

        // Player jumps on the road toward the closed gate
        val player = Player(
            characterId = CharacterId.ALI,
            position = Vector2(world.securityGate.x - 20f, 600f), // in mid-air jump on road (600f > 535f)
            isGrounded = false
        )

        physics.update(
            player = player,
            world = world,
            dt = 0.02f,
            moveInput = 1.0f,
            jumpTriggered = false,
            crouchInput = false,
            runInput = true
        )

        assertTrue(
            "Player cannot jump through the closed security gate on the road",
            player.position.x <= world.securityGate.x
        )
    }

    @Test
    fun `atomic move left and move right input methods`() {
        val engine = GameEngine()
        engine.startNewGame()

        assertEquals(0f, engine.moveInput)

        // Press left
        engine.setMoveLeft(true)
        assertEquals(-1f, engine.moveInput)

        // Also press right (cancels out)
        engine.setMoveRight(true)
        assertEquals(0f, engine.moveInput)

        // Release left while holding right
        engine.setMoveLeft(false)
        assertEquals(1f, engine.moveInput)

        // Release right
        engine.setMoveRight(false)
        assertEquals(0f, engine.moveInput)
    }

    @Test
    fun `companion follows leader smoothly without glitching`() {
        val physics = PhysicsSystem()
        val world = World()

        val leader = Player(characterId = CharacterId.ALI, position = Vector2(300f, 700f), isGrounded = true)
        val companion = Player(characterId = CharacterId.WALAA, position = Vector2(100f, 700f), isGrounded = true)

        // Run several ticks of companion AI
        for (i in 1..40) {
            physics.updateCompanion(companion, leader, world, 0.016f)
        }

        assertTrue("Companion should have moved towards leader", companion.position.x > 150f)
        assertTrue("Companion should maintain safe distance", companion.position.x < leader.position.x)
        assertEquals(700f, companion.position.y, 0.1f)
    }

    @Test
    fun `test camera follows active character and clamps to boundaries`() {
        val camera = Camera2D(viewportWidth = 800f, viewportHeight = 450f)
        val world = World(width = 3000f, height = 1000f)

        camera.follow(targetX = 50f, targetY = 700f, facingRight = true, world = world)
        assertEquals(0f, camera.position.x, 0.01f)

        for (i in 1..40) {
            camera.follow(targetX = 1500f, targetY = 700f, facingRight = true, world = world)
        }
        assertTrue("Camera should track forward", camera.position.x > 500f)
    }

    @Test
    fun `reaching tunnel entrance at 3200f triggers chapter completion`() {
        val engine = GameEngine()
        engine.startNewGame()

        assertFalse(engine.isChapterComplete)

        // Move both protagonists to tunnel portal
        engine.ali.position.set(3250f, 700f)
        engine.walaa.position.set(3200f, 700f)

        engine.tick(0.016f)
        assertTrue("Chapter 1 should be complete when reaching tunnel portal", engine.isChapterComplete)
        assertTrue(engine.narrativeDialogue?.contains("نفق وادي الظلام") == true)
    }
}
