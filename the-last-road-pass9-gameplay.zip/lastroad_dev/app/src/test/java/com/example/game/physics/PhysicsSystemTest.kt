package com.example.game.physics

import com.example.game.model.CharacterId
import com.example.game.model.Player
import com.example.game.model.Vector2
import com.example.game.model.World
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PhysicsSystemTest {
    @Test
    fun playerRemainsGroundedOnFlatRoad() {
        val world = World()
        val physics = PhysicsSystem()
        val player = Player(CharacterId.ALI, Vector2(160f, world.groundY))

        repeat(30) {
            physics.update(player, world, 1f / 60f, 0f, false, false, false)
        }

        assertTrue(player.isGrounded)
        assertEquals(world.groundY, player.position.y, 0.01f)
    }

    @Test
    fun horizontalInputMovesPlayer() {
        val world = World()
        val physics = PhysicsSystem()
        val player = Player(CharacterId.ALI, Vector2(160f, world.groundY))
        val startX = player.position.x

        repeat(20) {
            physics.update(player, world, 1f / 60f, 1f, false, false, false)
        }

        assertTrue("Right input should move the player", player.position.x > startX + 20f)
    }

    @Test
    fun jumpLaunchesAndReturnsPlayerToGround() {
        val world = World()
        val physics = PhysicsSystem()
        val player = Player(CharacterId.ALI, Vector2(160f, world.groundY))

        physics.update(player, world, 1f / 60f, 0f, true, false, false)
        assertFalse("Player should leave the ground after jumping", player.isGrounded)
        assertTrue("Jump velocity should point upward", player.velocity.y < 0f)

        repeat(120) {
            physics.update(player, world, 1f / 60f, 0f, false, false, false)
        }

        assertTrue("Player should land after a complete jump", player.isGrounded)
        assertEquals(world.groundY, player.position.y, 0.01f)
    }

    @Test
    fun playerCannotLeaveLeftWorldBoundary() {
        val world = World()
        val physics = PhysicsSystem()
        val player = Player(CharacterId.ALI, Vector2(10f, world.groundY))

        repeat(30) {
            physics.update(player, world, 1f / 60f, -1f, false, false, false)
        }

        assertTrue(player.position.x >= 0f)
    }

    @Test
    fun resetTransientStateDoesNotBreakNextGroundJump() {
        val world = World()
        val physics = PhysicsSystem()
        val player = Player(CharacterId.ALI, Vector2(160f, world.groundY))

        // Queue a jump while airborne, where it should remain buffered briefly.
        player.position.y = world.groundY - 100f
        player.velocity.y = 100f
        player.isGrounded = false
        physics.update(player, world, 1f / 60f, 0f, true, false, false)

        // Simulate starting/loading a run at a clean grounded checkpoint.
        physics.resetTransientState()
        player.position.y = world.groundY
        player.velocity.set(0f, 0f)
        player.isGrounded = true
        physics.update(player, world, 1f / 60f, 0f, false, false, false)

        assertTrue("A stale buffered jump must not launch after reset", player.isGrounded)
        assertEquals(0f, player.velocity.y, 0.01f)
    }
}
