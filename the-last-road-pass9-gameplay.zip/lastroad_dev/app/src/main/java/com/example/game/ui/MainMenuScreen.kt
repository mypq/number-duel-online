package com.example.game.ui

import android.app.Activity
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.core.GameEngine

/**
 * Atmospheric Arabic Main Menu for The Last Road.
 * Contains: New Game, Continue, Settings, and Exit.
 * (No character selection: both Ali and Walaa are journeying together).
 */
@Composable
fun MainMenuScreen(
    engine: GameEngine,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF04060A),
                        Color(0xFF0B1019),
                        Color(0xFF131A26)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        // Cinematic original concept-art backdrop for the title screen.
        Image(
            painter = painterResource(id = com.example.R.drawable.lastroad_menu_bg),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        // Dark edge gradient keeps the title and menu legible over the artwork.
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colorStops = arrayOf(
                            0.0f to Color(0xB804060A),
                            0.38f to Color(0x55101622),
                            1.0f to Color(0xE604060A)
                        )
                    )
                )
        )
        // Subtle background framing
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp)
        ) {
            // Horror Game Title
            Text(
                text = "الطريق الأخير",
                fontSize = 42.sp,
                fontWeight = FontWeight.Black,
                color = Color(0xFFF1F5FC),
                textAlign = TextAlign.Center,
                letterSpacing = 2.sp
            )

            Text(
                text = "THE LAST ROAD",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF90A3BE),
                letterSpacing = 6.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
            )

            // Story Subtitle establishing Ali and Walaa
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0x66182333),
                modifier = Modifier
                    .padding(bottom = 28.dp)
                    .border(1.dp, Color(0x334B6282), RoundedCornerShape(12.dp))
            ) {
                Text(
                    text = "مغامرة رعب سينمائية تجمع علي وولاء في طريق مهجور مقطوع",
                    fontSize = 12.sp,
                    color = Color(0xFFC7D5E8),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }

            // Menu Buttons Container
            Column(
                modifier = Modifier.width(320.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 1. New Game (Starts story with both Ali and Walaa)
                Button(
                    onClick = { engine.startNewGame() },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFB56525),
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("btn_new_game")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "لعبة جديدة (New Game)",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // 2. Continue Game
                Button(
                    onClick = { engine.continueGame() },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (engine.hasSavedGame) Color(0xFF243246) else Color(0xFF161F2C),
                        contentColor = if (engine.hasSavedGame) Color.White else Color(0xFF758599)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .border(
                            1.dp,
                            if (engine.hasSavedGame) Color(0xFF4C688C) else Color(0x33344458),
                            RoundedCornerShape(10.dp)
                        )
                        .testTag("btn_continue_game")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = if (engine.hasSavedGame) "متابعة اللعب (Continue)" else "متابعة اللعب (لا يوجد حفظ)",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // 3. Settings
                OutlinedButton(
                    onClick = { engine.navigateToSettings() },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_settings")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = Color(0xFFAEC4E0),
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "الإعدادات (Settings)",
                            color = Color(0xFFC7D8ED),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // 4. Exit
                OutlinedButton(
                    onClick = {
                        (context as? Activity)?.finish()
                    },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("btn_exit")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ExitToApp,
                            contentDescription = null,
                            tint = Color(0xFF8699B2),
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "خروج (Exit)",
                            color = Color(0xFF8699B2),
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

/**
 * Settings Screen for sound volumes and graphics quality.
 */
@Composable
fun SettingsScreen(
    engine: GameEngine,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF090D14))
            .padding(28.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color(0xF0121924),
            modifier = Modifier
                .width(420.dp)
                .border(1.5.dp, Color(0xFF3B4D66), RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { engine.navigateToMainMenu() },
                        modifier = Modifier.testTag("btn_settings_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "الرجوع",
                            tint = Color(0xFFD6E2F2)
                        )
                    }

                    Text(
                        text = "الإعدادات",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFEAF1FC)
                    )

                    Spacer(modifier = Modifier.size(48.dp))
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Master Volume Slider
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "مستوى الصوت العام (Master Volume)",
                            fontSize = 13.sp,
                            color = Color(0xFFC3D2E5)
                        )
                        Text(
                            text = "${(engine.masterVolume * 100).toInt()}%",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFE5A93C)
                        )
                    }
                    Slider(
                        value = engine.masterVolume,
                        onValueChange = { engine.masterVolume = it },
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFFE5A93C),
                            activeTrackColor = Color(0xFFE5A93C)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // SFX Volume Slider
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "المؤثرات الصوتية (Sound Effects)",
                            fontSize = 13.sp,
                            color = Color(0xFFC3D2E5)
                        )
                        Text(
                            text = "${(engine.sfxVolume * 100).toInt()}%",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF38B2AC)
                        )
                    }
                    Slider(
                        value = engine.sfxVolume,
                        onValueChange = { engine.sfxVolume = it },
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF38B2AC),
                            activeTrackColor = Color(0xFF38B2AC)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Graphics Quality Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "جودة الرسوم والمؤثرات",
                            fontSize = 13.sp,
                            color = Color(0xFFC3D2E5)
                        )
                        Text(
                            text = if (engine.isHighQuality) "عالية (ضباب سينمائي وإضاءة ديناميكية)" else "متوسطة (أداء محسن)",
                            fontSize = 11.sp,
                            color = Color(0xFF8697AE)
                        )
                    }
                    Switch(
                        checked = engine.isHighQuality,
                        onCheckedChange = { engine.isHighQuality = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFFE5A93C),
                            checkedTrackColor = Color(0xFF7A4F16)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = { engine.navigateToMainMenu() },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF34455C)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                ) {
                    Text(
                        text = "حفظ والرجوع (Save & Back)",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
