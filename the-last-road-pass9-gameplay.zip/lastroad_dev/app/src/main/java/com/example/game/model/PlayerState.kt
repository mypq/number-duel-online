package com.example.game.model

/**
 * Playable characters in The Last Road.
 */
enum class CharacterId(
    val displayNameAr: String,
    val displayNameEn: String,
    val abilityDescriptionAr: String,
    val canPushHeavyObjects: Boolean,
    val canCrawlNarrowPassages: Boolean
) {
    ALI(
        displayNameAr = "علي",
        displayNameEn = "Ali",
        abilityDescriptionAr = "القوة البدنية ودفع الأجسام الثقيلة",
        canPushHeavyObjects = true,
        canCrawlNarrowPassages = false
    ),
    WALAA(
        displayNameAr = "ولاء",
        displayNameEn = "Walaa",
        abilityDescriptionAr = "الرشاقة وعبور الممرات والفتحات الضيقة",
        canPushHeavyObjects = false,
        canCrawlNarrowPassages = true
    )
}

/**
 * Character movement & animation states.
 */
enum class MovementState {
    IDLE,
    WALKING,
    RUNNING,
    JUMPING,
    FALLING,
    CROUCHING,
    PUSHING,
    CRAWLING
}

/**
 * Entity data model for each protagonist.
 */
data class Player(
    val characterId: CharacterId,
    val position: Vector2,
    val velocity: Vector2 = Vector2(0f, 0f),
    val width: Float = if (characterId == CharacterId.ALI) 38f else 32f,
    val height: Float = if (characterId == CharacterId.ALI) 84f else 72f,
    var isGrounded: Boolean = true,
    var facingRight: Boolean = true,
    var state: MovementState = MovementState.IDLE,
    var isCrouching: Boolean = false,
    var isRunning: Boolean = false
) {
    val currentHeight: Float
        get() = when {
            isCrouching && characterId == CharacterId.WALAA -> height * 0.5f // 36px clearance for crawlways
            isCrouching -> height * 0.65f // 54.6px clearance
            else -> height
        }

    val bounds: Rect
        get() = Rect(
            left = position.x,
            top = position.y - currentHeight,
            right = position.x + width,
            bottom = position.y
        )
}
