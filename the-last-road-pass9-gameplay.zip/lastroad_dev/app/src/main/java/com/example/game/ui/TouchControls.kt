package com.example.game.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.South
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.core.GameEngine
import com.example.game.model.CharacterId

/**
 * High-responsiveness Mobile Touch HUD for Android Landscape.
 * Features 0ms instant-down action triggers, robust continuous hold tracking,
 * guaranteed release cleanup via try-finally, comfortable 72dp targets,
 * and zero recomposition overhead.
 */
@Composable
fun TouchControls(
    engine: GameEngine,
    modifier: Modifier = Modifier
) {
    val activeChar = engine.activeCharacterId
    val otherChar = if (activeChar == CharacterId.ALI) CharacterId.WALAA else CharacterId.ALI

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        // --- Top Bar: Active Character, Switch Button, Dialogue, Pause ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            // Character Info & Switch
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xCC131C28),
                    modifier = Modifier.border(1.5.dp, Color(0xFF4A6282), RoundedCornerShape(12.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(if (activeChar == CharacterId.ALI) Color(0xFFF5A623) else Color(0xFF2DD4BF))
                        )
                        Column {
                            Text(
                                text = "${activeChar.displayNameAr} (${activeChar.displayNameEn})",
                                color = Color(0xFFFFFFFF),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = activeChar.abilityDescriptionAr,
                                color = Color(0xFFB8CBE0),
                                fontSize = 10.sp
                            )
                        }
                    }
                }

                // In-Game Switch Button
                Button(
                    onClick = { engine.switchActiveCharacter() },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xEE2A3F58),
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .height(44.dp)
                        .border(1.5.dp, Color(0xFF6B8DB5), RoundedCornerShape(12.dp))
                        .testTag("btn_switch_character")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Cached,
                            contentDescription = "تبديل إلى ${otherChar.displayNameAr}",
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "تبديل إلى ${otherChar.displayNameAr}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Top Center: Story Dialogue Banner
            if (engine.narrativeDialogue != null) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xDD0E1520),
                    modifier = Modifier
                        .width(380.dp)
                        .padding(horizontal = 8.dp)
                        .border(1.5.dp, Color(0xFF435873), RoundedCornerShape(10.dp))
                ) {
                    Text(
                        text = engine.narrativeDialogue ?: "",
                        color = Color(0xFFF1F5FC),
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 16.sp,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                    )
                }
            }

            // Pause Button
            IconButton(
                onClick = { engine.setPauseState(!engine.isPaused) },
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(Color(0xCC131C28))
                    .border(1.5.dp, Color(0xFF4A6282), CircleShape)
                    .testTag("btn_pause")
            ) {
                Icon(
                    imageVector = Icons.Default.Pause,
                    contentDescription = "إيقاف مؤقت (Pause)",
                    tint = Color(0xFFE5EEFA),
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // --- Bottom Left: Movement D-Pad (Left / Right) with 0ms Instant Continuous Response ---
        Row(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(bottom = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            InstantHoldButton(
                icon = Icons.AutoMirrored.Filled.ArrowBack,
                label = "يسار",
                testTag = "btn_move_left",
                onPressChange = { isPressed ->
                    engine.setMoveLeft(isPressed)
                }
            )

            InstantHoldButton(
                icon = Icons.AutoMirrored.Filled.ArrowForward,
                label = "يمين",
                testTag = "btn_move_right",
                onPressChange = { isPressed ->
                    engine.setMoveRight(isPressed)
                }
            )
        }

        // --- Center Bottom: Contextual Interaction Button ---
        AnimatedVisibility(
            visible = engine.isInteractionAvailable,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 18.dp)
        ) {
            Button(
                onClick = { engine.triggerInteraction() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF288A58),
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier
                    .height(52.dp)
                    .border(2.dp, Color(0xFF4EE88D), RoundedCornerShape(22.dp))
                    .testTag("btn_interact")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Handyman,
                        contentDescription = "تفاعل",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = engine.interactionPromptLabel,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }

        // --- Bottom Right: Actions (Run toggle, Crouch toggle, Jump action) ---
        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            // Run Toggle
            ActionToggleButton(
                icon = Icons.Default.DirectionsRun,
                label = "ركض",
                isActive = engine.isRunActive,
                testTag = "btn_run",
                onClick = { engine.toggleRun() }
            )

            // Crouch Toggle
            ActionToggleButton(
                icon = Icons.Default.South,
                label = if (activeChar == CharacterId.WALAA) "زحف" else "انحناء",
                isActive = engine.isCrouchActive,
                testTag = "btn_crouch",
                onClick = { engine.toggleCrouch() }
            )

            // Jump Action (Instant Down Trigger)
            InstantActionButton(
                icon = Icons.Default.ArrowUpward,
                label = "قفز",
                testTag = "btn_jump",
                onTrigger = { engine.triggerJump() }
            )
        }
    }
}

/**
 * 0ms Latency Instant Hold Button for D-Pad Left/Right.
 * Immediate response on pointer contact down, continuous hold without accidental drop,
 * guaranteed immediate stop on finger release or focus loss via try-finally.
 */
@Composable
fun InstantHoldButton(
    icon: ImageVector,
    label: String,
    testTag: String,
    onPressChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var isPressed by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(if (isPressed) Color(0xEE395273) else Color(0xCC152130))
            .border(
                width = 2.dp,
                color = if (isPressed) Color(0xFF90BBEA) else Color(0xFF4C668A),
                shape = CircleShape
            )
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    down.consume()
                    isPressed = true
                    onPressChange(true)
                    try {
                        waitForUpOrCancellation()
                    } finally {
                        isPressed = false
                        onPressChange(false)
                    }
                }
            }
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isPressed) Color(0xFFFFFFFF) else Color(0xFFD6E3F5),
            modifier = Modifier.size(34.dp)
        )
    }
}

/**
 * Instant Action Button (triggers immediately on Touch DOWN, not on release).
 */
@Composable
fun InstantActionButton(
    icon: ImageVector,
    label: String,
    testTag: String,
    onTrigger: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isPressed by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(if (isPressed) Color(0xEE476690) else Color(0xDD1C2B3F))
            .border(2.dp, if (isPressed) Color(0xFF99C2F5) else Color(0xFF5D80AA), CircleShape)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    down.consume()
                    isPressed = true
                    onTrigger()
                    try {
                        waitForUpOrCancellation()
                    } finally {
                        isPressed = false
                    }
                }
            }
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color(0xFFFFFFFF),
                modifier = Modifier.size(30.dp)
            )
            Text(
                text = label,
                color = Color(0xFFC7DBF2),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/**
 * Toggleable State Button (e.g. Crouch or Run).
 */
@Composable
fun ActionToggleButton(
    icon: ImageVector,
    label: String,
    isActive: Boolean,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    IconButton(
        onClick = onClick,
        modifier = modifier
            .size(58.dp)
            .clip(CircleShape)
            .background(if (isActive) Color(0xFFD97724) else Color(0xCC152130))
            .border(
                width = 2.dp,
                color = if (isActive) Color(0xFFFBBF24) else Color(0xFF4C668A),
                shape = CircleShape
            )
            .testTag(testTag)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isActive) Color(0xFFFFFFFF) else Color(0xFFB8CDE5),
                modifier = Modifier.size(24.dp)
            )
            Text(
                text = label,
                color = if (isActive) Color(0xFFFFFFFF) else Color(0xFFA2B9D4),
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
