package com.example.game.model

/**
 * Platform or obstacle collision element.
 */
data class Platform(
    val bounds: Rect,
    val isGround: Boolean = true,
    val label: String = "Platform"
)

/**
 * Heavy movable steel box that requires Ali's physical strength to push.
 */
data class HeavyCrate(
    var x: Float = 920f,
    val y: Float = 700f,
    val width: Float = 65f,
    val height: Float = 65f,
    val targetSlotX: Float = 1040f
) {
    val bounds: Rect
        get() = Rect(x, y - height, x + width, y)

    val isPlacedUnderLedge: Boolean
        get() = x >= 1020f
}

/**
 * Narrow low-clearance crawl duct on the high catwalk accessible only by Walaa's agility.
 * Elevation: floor is at 520f, ceiling at 475f -> clearance is 45px.
 */
data class NarrowDuct(
    val left: Float = 1200f,
    val right: Float = 1380f,
    val floorY: Float = 520f,
    val ceilingY: Float = 475f // Clearance is 45px
) {
    val clearance: Float get() = floorY - ceilingY
}

/**
 * Road security barrier gate that opens via the electrical switch.
 * Blocks road passage from ground (700f) up to catwalk level (520f).
 */
data class SecurityGate(
    val x: Float = 1260f,
    val width: Float = 24f,
    val groundY: Float = 700f,
    val height: Float = 180f, // 700f - 180f = 520f (catwalk floor)
    var isOpen: Boolean = false,
    var openProgress: Float = 0f // 0.0 closed, 1.0 fully raised
) {
    val currentHeight: Float
        get() = height * (1f - openProgress)

    val bounds: Rect?
        get() = if (openProgress >= 0.95f) null else Rect(
            x,
            groundY - currentHeight,
            x + width,
            groundY
        )
}

/**
 * Electrical lever switch on the catwalk past the narrow crawl duct.
 */
data class GateLever(
    val x: Float = 1430f,
    val y: Float = 520f,
    var isActivated: Boolean = false
) {
    fun isNear(playerX: Float, playerY: Float): Boolean {
        return kotlin.math.abs(playerX - x) < 65f && kotlin.math.abs(playerY - y) < 45f
    }
}

/**
 * Environmental scenery element for atmosphere.
 */
data class SceneryElement(
    val x: Float,
    val y: Float,
    val type: SceneryType,
    val parallaxLayer: Float
)

enum class SceneryType {
    BROKEN_CAR_HEADLIGHTS,
    TELEPHONE_POLE,
    DEAD_TREE,
    ROAD_SIGN,
    ABANDONED_CAR_RUST,
    BARRIER,
    STREET_LAMP,
    FALLEN_BILLBOARD,
    TUNNEL_ENTRANCE
}

/**
 * World representation for Chapter 1: The Abandoned Road.
 * Features a verified step-by-step cooperative puzzle architecture:
 * 1. Ground highway at 700f.
 * 2. Heavy steel crate at 920f (pushable by Ali to 1040f, height 65f -> top at 635f).
 * 3. Scaffolding step at 1080f..1150f, y = 570f (jump height diff from crate is 65px; unreachable from ground).
 * 4. High security catwalk at 1140f..1500f, y = 520f (jump height diff from step is 50px).
 * 5. Narrow low crawl duct at 1200f..1380f, y = 520f (clearance 45px for Walaa only).
 * 6. Road security barrier gate at 1260f (blocks ground road up to 520f).
 * 7. Electrical lever on catwalk at 1430f, y = 520f.
 * 8. Descent scaffolding step at 1490f..1560f, y = 610f (drop of 90px to ground 700f).
 */
data class World(
    val width: Float = 3600f,
    val height: Float = 1000f,
    val groundY: Float = 700f,
    val heavyCrate: HeavyCrate = HeavyCrate(),
    val narrowDuct: NarrowDuct = NarrowDuct(),
    val securityGate: SecurityGate = SecurityGate(),
    val gateLever: GateLever = GateLever(),
    val platforms: List<Platform> = listOf(
        // Continuous main highway / asphalt road to the end of the level
        Platform(
            bounds = Rect(0f, 700f, 3600f, 1000f),
            isGround = true,
            label = "The Abandoned Road"
        ),
        // Elevated broken asphalt slabs / curbs for early traversal
        Platform(
            bounds = Rect(420f, 620f, 600f, 640f),
            isGround = false,
            label = "Collapsed Curb"
        ),
        Platform(
            bounds = Rect(720f, 600f, 880f, 620f),
            isGround = false,
            label = "Abandoned Truck Bed"
        ),

        // --- Cooperative Puzzle Platforms (Verified Reachable Geometry) ---
        // 1. Scaffolding climb step (accessible from crate top at 635f)
        Platform(
            bounds = Rect(1080f, 570f, 1150f, 585f),
            isGround = false,
            label = "Security Scaffolding Step"
        ),
        // 2. High security inspection catwalk spanning across the gate
        Platform(
            bounds = Rect(1140f, 520f, 1500f, 535f),
            isGround = false,
            label = "High Security Catwalk"
        ),
        // 3. Descent scaffolding step on far side of gate (allows Walaa to hop down to road)
        Platform(
            bounds = Rect(1490f, 610f, 1560f, 625f),
            isGround = false,
            label = "Descent Scaffolding Step"
        ),

        // Ledges beyond the gate
        Platform(
            bounds = Rect(1700f, 610f, 1960f, 630f),
            isGround = false,
            label = "Broken Guardrail"
        ),
        Platform(
            bounds = Rect(2200f, 620f, 2450f, 640f),
            isGround = false,
            label = "Overturned Freight Trailer"
        ),
        Platform(
            bounds = Rect(2650f, 600f, 2900f, 620f),
            isGround = false,
            label = "Collapsed Highway Slab"
        ),
        // Dark Valley Tunnel checkpoint platform
        Platform(
            bounds = Rect(3150f, 640f, 3450f, 660f),
            isGround = false,
            label = "Tunnel Inspection Platform"
        )
    ),
    val scenery: List<SceneryElement> = listOf(
        SceneryElement(80f, 700f, SceneryType.BROKEN_CAR_HEADLIGHTS, 1.0f),
        SceneryElement(280f, 700f, SceneryType.ROAD_SIGN, 1.0f),
        SceneryElement(450f, 700f, SceneryType.TELEPHONE_POLE, 1.0f),
        SceneryElement(700f, 700f, SceneryType.DEAD_TREE, 0.6f),
        SceneryElement(1150f, 700f, SceneryType.STREET_LAMP, 1.0f),
        SceneryElement(1600f, 700f, SceneryType.DEAD_TREE, 0.4f),
        SceneryElement(1850f, 700f, SceneryType.FALLEN_BILLBOARD, 0.8f),
        SceneryElement(2050f, 700f, SceneryType.TELEPHONE_POLE, 1.0f),
        SceneryElement(2350f, 700f, SceneryType.BARRIER, 1.0f),
        SceneryElement(2600f, 700f, SceneryType.ROAD_SIGN, 1.0f),
        SceneryElement(2850f, 700f, SceneryType.STREET_LAMP, 1.0f),
        SceneryElement(3300f, 700f, SceneryType.TUNNEL_ENTRANCE, 1.0f)
    )
) {
    // Most platforms are static. Cache the combined list and rebuild it only
    // when the movable crate changes position, rather than allocating a new
    // list from both physics and rendering on every frame.
    private var cachedCrateX: Float = Float.NaN
    private val cachedActivePlatforms: MutableList<Platform> = platforms.toMutableList<Platform>().apply {
        add(
            Platform(
                bounds = Rect(
                    heavyCrate.x,
                    heavyCrate.y - heavyCrate.height,
                    heavyCrate.x + heavyCrate.width,
                    heavyCrate.y - heavyCrate.height + 10f
                ),
                isGround = false,
                label = "Heavy Steel Crate Top"
            )
        )
    }

    /** Returns solid platforms, including the standable top of the movable crate. */
    fun getActivePlatforms(): List<Platform> {
        val crateX = heavyCrate.x
        if (cachedCrateX != crateX) {
            val crateTop = heavyCrate.y - heavyCrate.height
            cachedActivePlatforms[cachedActivePlatforms.lastIndex] = Platform(
                bounds = Rect(
                    crateX,
                    crateTop,
                    crateX + heavyCrate.width,
                    crateTop + 10f
                ),
                isGround = false,
                label = "Heavy Steel Crate Top"
            )
            cachedCrateX = crateX
        }
        return cachedActivePlatforms
    }
}
