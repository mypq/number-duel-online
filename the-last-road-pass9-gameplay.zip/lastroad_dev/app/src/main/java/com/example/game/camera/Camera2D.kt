package com.example.game.camera

import com.example.game.model.Vector2
import com.example.game.model.World
import kotlin.math.max

/**
 * Cinematic 2.5D side-scrolling camera.
 * Smooth tracking, direction lookahead, stable vertical horizon,
 * and strict world boundary clamping.
 */
class Camera2D(
    var viewportWidth: Float = 1280f,
    var viewportHeight: Float = 720f,
    val horizontalSmoothness: Float = 0.14f,
    val verticalSmoothness: Float = 0.04f
) {
    val position = Vector2(0f, 0f)
    private var lookaheadX: Float = 0f

    fun updateViewport(width: Float, height: Float) {
        if (width > 0f && height > 0f) {
            viewportWidth = width
            viewportHeight = height
        }
    }

    /**
     * Follows target with responsive lookahead and steady vertical framing.
     */
    fun follow(targetX: Float, targetY: Float, facingRight: Boolean, world: World) {
        // Lookahead in facing direction
        val desiredLookahead = if (facingRight) 90f else -90f
        lookaheadX += (desiredLookahead - lookaheadX) * 0.08f

        // Center on target with lookahead
        val targetCamX = (targetX + lookaheadX) - (viewportWidth / 2f)

        // Steady vertical framing: anchor camera primarily to road ground level so jumps do not violently shake the view
        val groundCamY = world.groundY - (viewportHeight * 0.75f)
        val elevatedOffset = if (targetY < world.groundY - 60f) (targetY - (world.groundY - 60f)) * 0.5f else 0f
        val targetCamY = groundCamY + elevatedOffset

        // Responsive horizontal lerp
        position.x += (targetCamX - position.x) * horizontalSmoothness
        // Soft vertical damping
        position.y += (targetCamY - position.y) * verticalSmoothness

        // Strictly clamp to world bounds: never expose empty void outside level
        val maxCamX = max(0f, world.width - viewportWidth)
        val maxCamY = max(0f, world.height - viewportHeight)

        position.x = position.x.coerceIn(0f, maxCamX)
        position.y = position.y.coerceIn(0f, maxCamY)
    }

    fun worldToScreenX(worldX: Float, parallaxFactor: Float = 1.0f): Float {
        return worldX - (position.x * parallaxFactor)
    }

    fun worldToScreenY(worldY: Float, parallaxFactor: Float = 1.0f): Float {
        return worldY - (position.y * parallaxFactor)
    }
}
