package com.example.game.physics

import com.example.game.model.CharacterId
import com.example.game.model.MovementState
import com.example.game.model.Player
import com.example.game.model.World
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.sign

/**
 * Stable, high-responsiveness 2D Physics and Collision Engine.
 * Features:
 * - Sub-stepping for frame-drop stability and tunneling prevention
 * - Instantaneous, crisp horizontal acceleration and braking
 * - Coyote time (100ms) and Jump buffering (120ms) for responsive jumping
 * - Precise ground & platform collision ensuring feet firmly touch the surface
 * - Strict puzzle condition enforcement (no bypasses, perfectly verified reachable flow)
 */
class PhysicsSystem(
    val gravity: Float = 1600f,
    val walkSpeed: Float = 220f,
    val runSpeed: Float = 360f,
    val crouchSpeed: Float = 120f,
    val pushSpeed: Float = 90f,
    val jumpVelocity: Float = -580f,
    val acceleration: Float = 8500f,
    val deceleration: Float = 9500f
) {

    private var coyoteTimer: Float = 0f
    private var jumpBufferTimer: Float = 0f

    /** Clears transient input timers when a run is restarted or restored. */
    fun resetTransientState() {
        coyoteTimer = 0f
        jumpBufferTimer = 0f
    }

    /**
     * Executes physics update with stable sub-stepping.
     * Prevents tunneling and large delta spikes when frames hitch.
     */
    fun update(
        player: Player,
        world: World,
        dt: Float,
        moveInput: Float,
        jumpTriggered: Boolean,
        crouchInput: Boolean,
        runInput: Boolean
    ): String? {
        val clampedDt = dt.coerceIn(0.001f, 0.05f)

        if (jumpTriggered) {
            jumpBufferTimer = 0.12f // 120ms jump buffer
        }

        // Keep each physics step at or below 1/60 s. A fixed upper step size
        // improves collision stability during frame drops without running an
        // unbounded number of sub-steps after a hitch.
        val maxStep = 1f / 60f
        val steps = ceil(clampedDt / maxStep).toInt().coerceIn(1, 3)
        val subDt = clampedDt / steps
        var feedback: String? = null
        repeat(steps) {
            val message = step(player, world, subDt, moveInput, crouchInput, runInput)
            if (message != null) feedback = message
        }
        return feedback
    }

    private fun step(
        player: Player,
        world: World,
        dt: Float,
        moveInput: Float,
        crouchInput: Boolean,
        runInput: Boolean
    ): String? {
        var feedbackMessage: String? = null

        // 1. Narrow duct auto-crouch constraint on high catwalk
        val inDuctZone = player.position.x + player.width > world.narrowDuct.left &&
                player.position.x < world.narrowDuct.right &&
                player.position.y <= world.narrowDuct.floorY + 8f

        if (inDuctZone && player.characterId == CharacterId.WALAA) {
            player.isCrouching = true
            player.isRunning = false
        } else {
            player.isCrouching = crouchInput
            player.isRunning = runInput && !player.isCrouching
        }

        // 2. Determine target speed
        val maxSpeed = when {
            player.isCrouching -> crouchSpeed
            player.isRunning -> runSpeed
            else -> walkSpeed
        }

        val targetVelocityX = moveInput * maxSpeed

        // 3. Instant Snappy Horizontal Acceleration & Immediate Directional Turnaround
        if (moveInput != 0f) {
            player.facingRight = moveInput > 0f

            val isTurningAround = (player.velocity.x > 0f && moveInput < 0f) || (player.velocity.x < 0f && moveInput > 0f)
            if (isTurningAround) {
                player.velocity.x = targetVelocityX * 0.4f
            } else {
                if (player.velocity.x < targetVelocityX) {
                    player.velocity.x = (player.velocity.x + acceleration * dt).coerceAtMost(targetVelocityX)
                } else if (player.velocity.x > targetVelocityX) {
                    player.velocity.x = (player.velocity.x - acceleration * dt).coerceAtLeast(targetVelocityX)
                }
            }
        } else {
            val brake = deceleration * dt
            if (abs(player.velocity.x) <= brake) {
                player.velocity.x = 0f
            } else if (player.velocity.x > 0f) {
                player.velocity.x -= brake
            } else {
                player.velocity.x += brake
            }
        }

        // 4. Update Coyote Time & Jump Buffer Timers
        if (player.isGrounded) {
            coyoteTimer = 0.10f
        } else {
            coyoteTimer = (coyoteTimer - dt).coerceAtLeast(0f)
        }

        if (jumpBufferTimer > 0f) {
            jumpBufferTimer = (jumpBufferTimer - dt).coerceAtLeast(0f)
        }

        // A jump pressed inside the low-clearance duct must not remain buffered
        // and unexpectedly fire just after leaving the restricted area.
        if (inDuctZone) {
            jumpBufferTimer = 0f
        }

        // 5. Responsive Jump Trigger
        val canJump = (player.isGrounded || coyoteTimer > 0f) && !player.isCrouching && !inDuctZone
        if (jumpBufferTimer > 0f && canJump) {
            player.velocity.y = jumpVelocity
            player.isGrounded = false
            coyoteTimer = 0f
            jumpBufferTimer = 0f
        }

        // 6. Gravity update
        if (!player.isGrounded) {
            player.velocity.y += gravity * dt
        }

        // 7. Predict Position Changes
        val prevY = player.position.y
        val prevX = player.position.x
        var newX = prevX + player.velocity.x * dt
        val newY = prevY + player.velocity.y * dt

        // --- 8. Puzzle Interaction & Obstacle Resolution ---

        // A. Heavy Steel Crate interaction
        val crate = world.heavyCrate
        val crateTopY = crate.y - crate.height // 635f
        val isBelowCrateTop = prevY > crateTopY + 6f
        val collidesWithCrateHorizontally = (newX + player.width >= crate.x) && (newX <= crate.x + crate.width)

        var isPushingCrate = false
        if (isBelowCrateTop && collidesWithCrateHorizontally) {
            if (player.characterId == CharacterId.ALI) {
                if (moveInput > 0f) {
                    if (crate.x < crate.targetSlotX) {
                        isPushingCrate = true
                        player.velocity.x = pushSpeed
                        val pushedCrateX = (newX + player.width).coerceAtMost(crate.targetSlotX)
                        crate.x = pushedCrateX
                        newX = pushedCrateX - player.width
                        if (crate.isPlacedUnderLedge) {
                            feedbackMessage = "تم وضع الصندوق تحت الحافة! الآن تستطيع ولاء الصعود."
                        }
                    } else {
                        newX = crate.x - player.width
                        player.velocity.x = 0f
                    }
                } else if (moveInput < 0f && prevX > crate.x) {
                    newX = (crate.x + crate.width).coerceAtLeast(newX)
                }
            } else {
                // Walaa cannot push the crate
                if (moveInput > 0f && prevX <= crate.x) {
                    newX = crate.x - player.width
                    player.velocity.x = 0f
                    feedbackMessage = "الصندوق ثقيل جداً.. يحتاج لقوة علي لدفعه!"
                } else if (moveInput < 0f && prevX >= crate.x + crate.width) {
                    newX = crate.x + crate.width
                    player.velocity.x = 0f
                }
            }
        }

        // B. High Ledge Vertical Lip & Reach Check (Prevents skipping crate puzzle)
        // Scaffolding step begins at x = 1080f, y = 595f
        val scaffoldingStep = world.platforms.find { it.label == "Security Scaffolding Step" }
        if (scaffoldingStep != null) {
            val ledgeX = scaffoldingStep.bounds.left
            val ledgeFloorY = scaffoldingStep.bounds.top
            // If player is below the scaffolding step
            if (player.position.y > ledgeFloorY + 8f) {
                if (newX + player.width >= ledgeX && prevX + player.width <= ledgeX) {
                    // Must have pushed crate to slot to climb
                    if (!crate.isPlacedUnderLedge) {
                        newX = ledgeX - player.width
                        player.velocity.x = 0f
                        if (moveInput > 0f) {
                            feedbackMessage = "الحافة مرتفعة جداً.. يجب دفع الصندوق الفولاذي أولاً للصعود!"
                        }
                    }
                }
            }
        }

        // C. Narrow Duct Low-Ceiling Check on Catwalk (Clearance 45px)
        val duct = world.narrowDuct
        val onCatwalk = player.position.y <= duct.floorY + 12f
        if (onCatwalk) {
            if (player.characterId == CharacterId.ALI) {
                if (newX + player.width > duct.left && newX < duct.right) {
                    if (prevX + player.width <= duct.left) {
                        newX = duct.left - player.width
                        player.velocity.x = 0f
                        feedbackMessage = "الممر منخفض وضيق جداً.. ولاء وحدها تستطيع الزحف عبره!"
                    }
                }
            } else {
                if (newX + player.width > duct.left && newX < duct.right) {
                    player.isCrouching = true
                }
            }
        }

        // D. Security Roadblock Gate Barrier Check
        // The gate barrier is on the road level beneath the catwalk (y > 520f)
        val gate = world.securityGate
        if (!gate.isOpen) {
            // Blocks horizontal passage on the road level below catwalk
            if (player.position.y > 520f) {
                if (newX + player.width >= gate.x && prevX + player.width <= gate.x) {
                    newX = gate.x - player.width
                    player.velocity.x = 0f
                    feedbackMessage = "البوابة مغلقة! ابحث عن رافعة التحكم على الجانب الآخر."
                } else if (newX <= gate.x + gate.width && prevX >= gate.x + gate.width) {
                    newX = gate.x + gate.width
                    player.velocity.x = 0f
                }
            }
        }

        // 9. World Boundaries Clamping
        val clampedX = newX.coerceIn(0f, world.width - player.width)
        if (clampedX == 0f || clampedX == world.width - player.width) {
            player.velocity.x = 0f
        }
        player.position.x = clampedX

        // 10. Robust Ground & Platform Collision Resolution
        var landedOnPlatform = false
        var resolvedY = newY

        val activePlatforms = world.getActivePlatforms()
        for (platform in activePlatforms) {
            val pBounds = platform.bounds
            // Horizontal footprint overlap check
            val overlapX = (clampedX + player.width > pBounds.left + 1f) && (clampedX < pBounds.right - 1f)
            if (overlapX) {
                val prevFoot = prevY
                val newFoot = newY
                // Landing on platform top surface
                if (prevFoot <= pBounds.top + 10f && newFoot >= pBounds.top - 2f && player.velocity.y >= 0f) {
                    resolvedY = pBounds.top
                    landedOnPlatform = true
                    break
                }
            }
        }

        if (landedOnPlatform) {
            player.position.y = resolvedY
            player.velocity.y = 0f
            player.isGrounded = true
        } else {
            if (newY >= world.groundY) {
                player.position.y = world.groundY
                player.velocity.y = 0f
                player.isGrounded = true
            } else {
                player.position.y = newY
                player.isGrounded = false
            }
        }

        // 11. State & Animation Update
        player.state = when {
            isPushingCrate -> MovementState.PUSHING
            inDuctZone && player.characterId == CharacterId.WALAA -> MovementState.CRAWLING
            !player.isGrounded && player.velocity.y < 0f -> MovementState.JUMPING
            !player.isGrounded && player.velocity.y >= 0f -> MovementState.FALLING
            player.isCrouching -> MovementState.CROUCHING
            abs(player.velocity.x) > 15f && player.isRunning -> MovementState.RUNNING
            abs(player.velocity.x) > 15f -> MovementState.WALKING
            else -> MovementState.IDLE
        }

        return feedbackMessage
    }

    /**
     * Updates companion AI: follows the active character smoothly and reliably.
     */
    fun updateCompanion(
        companion: Player,
        leader: Player,
        world: World,
        dt: Float
    ) {
        val clampedDt = dt.coerceIn(0.001f, 0.05f)

        val duct = world.narrowDuct
        val leaderInDuct = leader.position.x >= duct.left && leader.position.x <= duct.right && leader.position.y <= duct.floorY + 12f
        val leaderBeyondGate = leader.position.x > world.securityGate.x && !world.securityGate.isOpen

        // Ali waits on road before closed gate or before duct if Walaa went ahead
        if (companion.characterId == CharacterId.ALI && (leaderInDuct || leaderBeyondGate)) {
            companion.velocity.x = 0f
            companion.facingRight = true
            companion.state = MovementState.IDLE
            return
        }

        val dx = leader.position.x - companion.position.x
        val followDistance = 75f

        if (abs(dx) > followDistance + 25f) {
            val dir = sign(dx)
            companion.facingRight = dir > 0f
            val targetSpeed = (walkSpeed * 0.95f) * dir
            companion.velocity.x = targetSpeed

            val nextX = companion.position.x + companion.velocity.x * clampedDt
            companion.position.x = nextX.coerceIn(0f, world.width - companion.width)
            companion.state = MovementState.WALKING
        } else {
            companion.velocity.x = 0f
            companion.state = MovementState.IDLE
        }

        // Companion platform & ground positioning
        var landedOnPlatform = false
        for (platform in world.getActivePlatforms()) {
            val pBounds = platform.bounds
            val overlapX = (companion.position.x + companion.width > pBounds.left + 2f) && (companion.position.x < pBounds.right - 2f)
            if (overlapX) {
                if (companion.position.y <= pBounds.top + 8f && companion.position.y >= pBounds.top - 8f) {
                    companion.position.y = pBounds.top
                    landedOnPlatform = true
                    break
                }
            }
        }
        if (!landedOnPlatform) {
            if (companion.position.y >= world.groundY) {
                companion.position.y = world.groundY
            }
        }
        companion.isGrounded = true
    }
}
