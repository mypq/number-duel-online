package com.example.game.core

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.game.camera.Camera2D
import com.example.game.model.CharacterId
import com.example.game.model.Player
import com.example.game.model.Vector2
import com.example.game.model.World
import com.example.game.physics.PhysicsSystem
import kotlin.math.sin

enum class GameScreenState {
    MAIN_MENU,
    PLAYING,
    SETTINGS
}

/** Simple deterministic AI states for the first original creature. */
enum class MonsterState { PATROL, INVESTIGATE, CHASE, SEARCH, RETURN }

/**
 * Authoritative Game Engine for The Last Road.
 * Manages dual protagonist simulation, cooperative mechanics, and screen navigation.
 */
class GameEngine(private val context: Context? = null) {

    var screenState by mutableStateOf(GameScreenState.MAIN_MENU)
        private set

    val world = World()
    val physics = PhysicsSystem()
    val camera = Camera2D()

    // Both Ali and Walaa exist simultaneously in the world
    var ali by mutableStateOf(
        Player(
            characterId = CharacterId.ALI,
            position = Vector2(160f, 700f),
            width = 38f,
            height = 84f
        )
    )
        private set

    var walaa by mutableStateOf(
        Player(
            characterId = CharacterId.WALAA,
            position = Vector2(210f, 700f),
            width = 32f,
            height = 72f
        )
    )
        private set

    var activeCharacterId by mutableStateOf(CharacterId.ALI)
        private set

    val activePlayer: Player
        get() = if (activeCharacterId == CharacterId.ALI) ali else walaa

    val companionPlayer: Player
        get() = if (activeCharacterId == CharacterId.ALI) walaa else ali

    // Atomic input state tracking
    @Volatile private var isLeftHeld: Boolean = false
    @Volatile private var isRightHeld: Boolean = false

    var moveInput by mutableFloatStateOf(0f)
        private set

    var jumpRequested by mutableStateOf(false)
        private set

    var isCrouchActive by mutableStateOf(false)
        private set

    var isRunActive by mutableStateOf(false)
        private set

    var isPaused by mutableStateOf(false)
        private set

    // Plain float property for rendering animation, avoids recomposition churn
    var fogOffset: Float = 0f

    // Frame counter read strictly inside Canvas DrawScope to trigger draw phase without recomposing UI
    var renderFrame by mutableLongStateOf(0L)
        private set
    private var internalFrameCount = 0L

    // Story narrative prompt & contextual feedback
    var narrativeDialogue by mutableStateOf<String?>(
        "تعطلت سيارتنا في هذا الطريق المهجور... يجب أن نتعاون لنجد مخرجاً."
    )
        private set

    // Contextual interaction availability
    var isInteractionAvailable by mutableStateOf(false)
        private set

    var interactionPromptLabel by mutableStateOf("")
        private set

    // Story objectives and persistent chapter-1 discoveries.
    var currentObjective by mutableStateOf("افحص السيارة المعطلة وابحث عن إشارة للطريق")
        private set
    private var carInspected = false
    private var signInspected = false
    private var firstStoryBeatShown = false
    private var secondStoryBeatShown = false
    // Last safe roadside checkpoint used after the creature catches the active character.
    private var checkpointWorldX = 160f
    private var checkpointCompanionOffset = 50f
    private var checkpointMilestone = 0

    // Monster AI: state and world position are owned by the engine, not the renderer.
    var monsterState by mutableStateOf(MonsterState.PATROL)
        private set
    var monsterWorldX by mutableFloatStateOf(2480f)
        private set
    private var monsterStateTimer = 0f
    private var lastKnownPlayerX = 0f
    var isPlayerCaught by mutableStateOf(false)
        private set

    // Save state indicator
    var hasSavedGame by mutableStateOf(false)
        private set

    // Level completion reached
    var isChapterComplete by mutableStateOf(false)
        private set

    // Settings
    var masterVolume by mutableFloatStateOf(0.8f)
    var sfxVolume by mutableFloatStateOf(0.9f)
    var isHighQuality by mutableStateOf(true)

    init {
        checkSavedProgress()
    }

    private fun checkSavedProgress() {
        val prefs = context?.getSharedPreferences("the_last_road_save", Context.MODE_PRIVATE)
        hasSavedGame = prefs?.getBoolean("has_save", false) ?: false
    }

    fun startNewGame() {
        // Reset transient physics input so a buffered jump from the previous run cannot leak into this run.
        physics.resetTransientState()

        // Reset world & puzzle
        world.heavyCrate.x = 920f
        world.securityGate.isOpen = false
        world.securityGate.openProgress = 0f
        world.gateLever.isActivated = false

        // Start both characters together beside their broken vehicle
        ali.position.set(160f, 700f)
        ali.velocity.set(0f, 0f)
        ali.isGrounded = true

        walaa.position.set(210f, 700f)
        walaa.velocity.set(0f, 0f)
        walaa.isGrounded = true

        activeCharacterId = CharacterId.ALI
        isLeftHeld = false
        isRightHeld = false
        moveInput = 0f
        jumpRequested = false
        isCrouchActive = false
        isRunActive = false
        isPaused = false
        isChapterComplete = false
        carInspected = false
        signInspected = false
        firstStoryBeatShown = false
        secondStoryBeatShown = false
        checkpointWorldX = 160f
        checkpointCompanionOffset = 50f
        checkpointMilestone = 0
        currentObjective = "افحص السيارة المعطلة وابحث عن إشارة للطريق"
        monsterState = MonsterState.PATROL
        monsterWorldX = 2480f
        monsterStateTimer = 0f
        lastKnownPlayerX = 0f
        isPlayerCaught = false

        narrativeDialogue = "علي: المحرك مات تماماً... لازم نلقى مساعدة قبل لا يشتد المطر."

        screenState = GameScreenState.PLAYING
    }

    fun continueGame() {
        // Loading a checkpoint starts with clean jump/coyote timers and no stale physics input.
        physics.resetTransientState()
        val prefs = context?.getSharedPreferences("the_last_road_save", Context.MODE_PRIVATE)
        if (prefs != null && prefs.getBoolean("has_save", false)) {
            ali.position.x = prefs.getFloat("ali_x", 160f)
            ali.position.y = prefs.getFloat("ali_y", 700f)
            walaa.position.x = prefs.getFloat("walaa_x", 210f)
            walaa.position.y = prefs.getFloat("walaa_y", 700f)

            world.heavyCrate.x = prefs.getFloat("crate_x", 920f)
            val gateOpen = prefs.getBoolean("gate_open", false)
            world.securityGate.isOpen = gateOpen
            world.securityGate.openProgress = if (gateOpen) 1.0f else 0f
            world.gateLever.isActivated = gateOpen
            checkpointWorldX = prefs.getFloat("checkpoint_x", ali.position.x)
            checkpointCompanionOffset = prefs.getFloat("checkpoint_companion_offset", 50f)
            checkpointMilestone = prefs.getInt("checkpoint_milestone", 0)

            val activeCharStr = prefs.getString("active_char", CharacterId.ALI.name)
            activeCharacterId = try {
                CharacterId.valueOf(activeCharStr ?: CharacterId.ALI.name)
            } catch (e: Exception) {
                CharacterId.ALI
            }

            narrativeDialogue = prefs.getString("dialogue", "مرحباً بكم مجدداً في الطريق الأخير.")
        } else {
            // No save file yet, start fresh
            startNewGame()
            return
        }

        isLeftHeld = false
        isRightHeld = false
        moveInput = 0f
        jumpRequested = false
        isCrouchActive = false
        isRunActive = false
        isPaused = false
        isChapterComplete = false
        screenState = GameScreenState.PLAYING
    }

    fun saveCheckpoint(message: String? = null) {
        val prefs = context?.getSharedPreferences("the_last_road_save", Context.MODE_PRIVATE)
        prefs?.edit()?.apply {
            putBoolean("has_save", true)
            putFloat("ali_x", ali.position.x)
            putFloat("ali_y", ali.position.y)
            putFloat("walaa_x", walaa.position.x)
            putFloat("walaa_y", walaa.position.y)
            putFloat("crate_x", world.heavyCrate.x)
            putFloat("checkpoint_x", checkpointWorldX)
            putFloat("checkpoint_companion_offset", checkpointCompanionOffset)
            putInt("checkpoint_milestone", checkpointMilestone)
            putBoolean("gate_open", world.securityGate.isOpen)
            putString("active_char", activeCharacterId.name)
            if (message != null) {
                putString("dialogue", message)
            }
            apply()
        }
        hasSavedGame = true
    }

    fun navigateToMainMenu() {
        isPaused = false
        screenState = GameScreenState.MAIN_MENU
    }

    fun navigateToSettings() {
        screenState = GameScreenState.SETTINGS
    }

    /**
     * In-game character switching between Ali and Walaa.
     */
    fun switchActiveCharacter() {
        if (isPaused || screenState != GameScreenState.PLAYING) return

        // Safely halt ongoing input transitions
        isLeftHeld = false
        isRightHeld = false
        moveInput = 0f
        jumpRequested = false
        isCrouchActive = false
        isRunActive = false

        activeCharacterId = if (activeCharacterId == CharacterId.ALI) {
            narrativeDialogue = "التحكم الآن: ولاء (الرشاقة والممرات الضيقة)"
            CharacterId.WALAA
        } else {
            narrativeDialogue = "التحكم الآن: علي (القوة ودفع الأجسام)"
            CharacterId.ALI
        }
    }

    fun setMoveLeft(held: Boolean) {
        isLeftHeld = held
        updateMovement()
    }

    fun setMoveRight(held: Boolean) {
        isRightHeld = held
        updateMovement()
    }

    private fun updateMovement() {
        moveInput = when {
            isLeftHeld && !isRightHeld -> -1f
            isRightHeld && !isLeftHeld -> 1f
            else -> 0f
        }
    }

    fun setMovement(direction: Float) {
        moveInput = direction.coerceIn(-1f, 1f)
    }

    fun triggerJump() {
        // Always queue the input while gameplay is active. PhysicsSystem applies
        // the jump buffer and decides when the player is eligible to jump.
        // Gating on isGrounded here discards presses made just before landing.
        if (!isPaused && screenState == GameScreenState.PLAYING && !isCrouchActive) {
            jumpRequested = true
        }
    }

    fun toggleCrouch() {
        if (!isPaused) {
            isCrouchActive = !isCrouchActive
            if (isCrouchActive) {
                isRunActive = false
            }
        }
    }

    fun toggleRun() {
        if (!isPaused && !isCrouchActive) {
            isRunActive = !isRunActive
        }
    }

    fun setPauseState(paused: Boolean) {
        isPaused = paused
        if (paused) {
            isLeftHeld = false
            isRightHeld = false
            moveInput = 0f
            jumpRequested = false
        }
    }

    /**
     * Executes contextual interaction when near mechanisms like the gate lever.
     */
    fun triggerInteraction() {
        if (isPaused || screenState != GameScreenState.PLAYING) return

        val x = activePlayer.position.x
        // Opening investigation beats make the road feel like a story, not an empty platform.
        if (!carInspected && x < 360f) {
            carInspected = true
            currentObjective = "اتبع اللافتة وافهم لماذا الطريق خالٍ"
            narrativeDialogue = "ولاء: السيارة ما راح تشتغل. لقيت آثار أقدام طالعة من هنا... بس ماكو أي أثر راجع."
            saveCheckpoint(narrativeDialogue)
            return
        }
        if (carInspected && !signInspected && x in 250f..620f) {
            signInspected = true
            currentObjective = "اعبر الحاجز وافتح البوابة الأمنية"
            narrativeDialogue = "علي: اللافتة تشير لبغداد وكربلاء بنفس الوقت... هذا مو منطقي. ولاء: خلّينا نبتعد عن الطريق الرئيسي."
            saveCheckpoint(narrativeDialogue)
            return
        }

        val lever = world.gateLever
        if (lever.isNear(activePlayer.position.x, activePlayer.position.y)) {
            lever.isActivated = true
            world.securityGate.isOpen = true
            narrativeDialogue = "انفتحت البوابة بصرير قوي. من بعيد، ردّ صدى يشبه صوت إنسان... لكنه أطول من اللازم."
            currentObjective = "وصلوا إلى مدخل نفق وادي الظلام معاً"
            saveCheckpoint(narrativeDialogue)
        }
    }

    /**
     * Main authoritative tick update.
     */
    fun tick(dt: Float) {
        if (isPaused || screenState != GameScreenState.PLAYING) return

        // 1. Advance atmospheric drifting mist (plain float, no recomposition)
        fogOffset = (fogOffset + dt * 45f) % 2000f

        // 2. Animate security gate lifting if open
        if (world.securityGate.isOpen && world.securityGate.openProgress < 1.0f) {
            world.securityGate.openProgress = (world.securityGate.openProgress + dt * 0.9f).coerceAtMost(1.0f)
        }

        // 3. Update active player physics
        val jump = jumpRequested
        jumpRequested = false

        val feedback = physics.update(
            player = activePlayer,
            world = world,
            dt = dt,
            moveInput = moveInput,
            jumpTriggered = jump,
            crouchInput = isCrouchActive,
            runInput = isRunActive
        )

        // Only update dialogue state if changed to avoid recomposition churn
        if (feedback != null && feedback != narrativeDialogue) {
            narrativeDialogue = feedback
        }

        // 4. Update inactive companion AI
        physics.updateCompanion(
            companion = companionPlayer,
            leader = activePlayer,
            world = world,
            dt = dt
        )

        // 5. Creature AI. Crouching substantially reduces detection range; running increases it.
        updateMonsterAi(dt)
        if (isPlayerCaught && kotlin.math.abs(activePlayer.position.x - checkpointWorldX) > 120f) {
            isPlayerCaught = false
        }

        // 6. Story beats and safe checkpoints. Milestones are saved once, so retries
        // resume at the last safe stretch rather than forcing the player to replay the opening.
        if (!firstStoryBeatShown && activePlayer.position.x >= 1750f) {
            firstStoryBeatShown = true
            narrativeDialogue = "ولاء: شفت شي يتحرك بين الأشجار؟ علي: لا تطالع وراك... كمّلي مشي."
            currentObjective = "ابقَ قريباً من شريكك وتجاوز الحطام"
            activateRoadsideCheckpoint(1700f, 1, "نقطة حفظ: تجاوزت الحاجز الأول.")
        }
        if (!secondStoryBeatShown && activePlayer.position.x >= 2550f) {
            secondStoryBeatShown = true
            narrativeDialogue = "صوت مجهول من الظلام: ...علي... ولاء... توقّفا..."
            currentObjective = "اهرب من الطريق المكشوف وواصل إلى النفق"
            activateRoadsideCheckpoint(2500f, 2, "نقطة حفظ: وصلت إلى الطريق المكشوف.")
        }

        // 6. Check level completion checkpoint at Dark Valley Tunnel entrance
        if (!isChapterComplete && activePlayer.position.x >= 3200f && companionPlayer.position.x >= 3100f) {
            isChapterComplete = true
            narrativeDialogue = "علي: مهما كان داخل النفق، ما نكدر نرجع. ولاء: إذا افترقنا، نلتقي عند أول ضوء. — نهاية الفصل الأول —"
            currentObjective = "الفصل الأول مكتمل — تابع بالفصل التالي عند توفره"
            saveCheckpoint(narrativeDialogue)
        }

        // 6. Update interaction prompt only on state transitions
        val lever = world.gateLever
        val nearCar = activePlayer.position.x < 360f && !carInspected
        val nearSign = carInspected && !signInspected && activePlayer.position.x in 250f..620f
        val canPullLever = lever.isNear(activePlayer.position.x, activePlayer.position.y) && !lever.isActivated
        val canInvestigate = nearCar || nearSign
        val available = canPullLever || canInvestigate
        val nextPrompt = when {
            nearCar -> "افحص السيارة"
            nearSign -> "افحص اللافتة"
            canPullLever -> "اسحب الرافعة"
            else -> ""
        }
        if (available != isInteractionAvailable || nextPrompt != interactionPromptLabel) {
            isInteractionAvailable = available
            interactionPromptLabel = nextPrompt
        }

        // 7. Camera follows active character with smooth lerp
        camera.follow(
            targetX = activePlayer.position.x,
            targetY = activePlayer.position.y,
            facingRight = activePlayer.facingRight,
            world = world
        )

        // 8. Signal draw-phase update for Canvas without re-evaluating UI composables
        renderFrame = ++internalFrameCount
    }
    /** Save a safe chapter milestone after the story event has fired. */
    private fun activateRoadsideCheckpoint(x: Float, milestone: Int, message: String) {
        if (milestone <= checkpointMilestone) return
        checkpointWorldX = x
        checkpointCompanionOffset = 50f
        checkpointMilestone = milestone
        saveCheckpoint(message)
    }

    /**
     * First playable stealth loop: patrol -> investigate -> chase -> search -> return.
     * The player can break line-of-attention by crouching behind distance; catching resets to a fair checkpoint.
     */
    private fun updateMonsterAi(dt: Float) {
        monsterStateTimer += dt.coerceIn(0f, 0.05f)
        val playerX = activePlayer.position.x
        val distance = kotlin.math.abs(monsterWorldX - playerX)
        // The wrecked billboard, overturned trailer and collapsed slab act as cover.
        // Crouching inside one of these zones breaks visual detection until the player moves away.
        val behindCover = isCrouchActive && listOf(1850f, 2325f, 2775f).any { kotlin.math.abs(playerX - it) < 105f }
        val detectionRange = when {
            behindCover -> 0f
            isCrouchActive -> 95f
            isRunActive -> 680f
            else -> 390f
        }

        when (monsterState) {
            MonsterState.PATROL -> {
                // Creature wakes only after the player reaches the exposed stretch of road.
                if (playerX >= 1950f && !behindCover && distance <= maxOf(detectionRange, if (isRunActive) 700f else 620f)) {
                    monsterState = MonsterState.INVESTIGATE
                    monsterStateTimer = 0f
                    lastKnownPlayerX = playerX
                    narrativeDialogue = "ولاء: لا تتحرك بسرعة... أعتقد أنه سمعنا."
                } else {
                    monsterWorldX += sin(monsterStateTimer * 0.7f) * dt * 9f
                }
            }
            MonsterState.INVESTIGATE -> {
                lastKnownPlayerX = playerX
                if (!behindCover && distance <= if (isCrouchActive) 85f else 260f) {
                    monsterState = MonsterState.CHASE
                    monsterStateTimer = 0f
                    narrativeDialogue = "علي: اركضي! لقد رآنا!"
                    currentObjective = "اهرب من المخلوق واختبئ خلف الحطام"
                } else if (monsterStateTimer > 3.2f) {
                    monsterState = MonsterState.SEARCH
                    monsterStateTimer = 0f
                }
            }
            MonsterState.CHASE -> {
                lastKnownPlayerX = playerX
                val direction = if (playerX >= monsterWorldX) 1f else -1f
                // The creature is faster than a walk, but a sustained sprint can create space.
                monsterWorldX += direction * 245f * dt.coerceIn(0f, 0.05f)
                if (behindCover || distance > 820f || (isCrouchActive && distance > 150f)) {
                    monsterState = MonsterState.SEARCH
                    monsterStateTimer = 0f
                    narrativeDialogue = "اختفى صوته... لا تتحرك حتى تتأكد أنه ابتعد."
                } else if (distance < 42f) {
                    // Non-lethal checkpoint recovery so the opening remains playable.
                    activePlayer.position.x = checkpointWorldX
                    activePlayer.position.y = 700f
                    activePlayer.velocity.x = 0f
                    activePlayer.velocity.y = 0f
                    activePlayer.isGrounded = true
                    companionPlayer.position.x = (checkpointWorldX - checkpointCompanionOffset).coerceAtLeast(40f)
                    companionPlayer.position.y = 700f
                    companionPlayer.velocity.x = 0f
                    companionPlayer.velocity.y = 0f
                    companionPlayer.isGrounded = true
                    monsterWorldX = maxOf(2310f, checkpointWorldX + 650f)
                    monsterState = MonsterState.SEARCH
                    monsterStateTimer = 0f
                    isPlayerCaught = true
                    narrativeDialogue = "أمسك بك للحظة! نجوت بصعوبة... اختبئ وراقب حركته."
                    currentObjective = "اختبئ ثم تابع نحو النفق"
                    saveCheckpoint(narrativeDialogue)
                }
            }
            MonsterState.SEARCH -> {
                if (!behindCover && !isCrouchActive && distance < 310f) {
                    monsterState = MonsterState.CHASE
                    monsterStateTimer = 0f
                } else if (monsterStateTimer > 4.5f) {
                    monsterState = MonsterState.RETURN
                    monsterStateTimer = 0f
                }
            }
            MonsterState.RETURN -> {
                val homeX = 2480f
                val delta = homeX - monsterWorldX
                if (kotlin.math.abs(delta) < 18f) {
                    monsterWorldX = homeX
                    monsterState = MonsterState.PATROL
                    monsterStateTimer = 0f
                } else {
                    monsterWorldX += kotlin.math.sign(delta) * 72f * dt.coerceIn(0f, 0.05f)
                }
            }
        }
    }

}
