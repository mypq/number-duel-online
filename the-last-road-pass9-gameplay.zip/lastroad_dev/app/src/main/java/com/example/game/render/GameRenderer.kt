package com.example.game.render

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.game.camera.Camera2D
import com.example.game.model.CharacterId
import com.example.game.model.MovementState
import com.example.game.model.Player
import com.example.game.model.SceneryType
import com.example.game.model.World
import kotlin.math.abs
import kotlin.math.sin

/**
 * 2.5D Cinematic Horror Renderer for The Last Road.
 * Optimized to minimize object allocations: reuses Path instances,
 * renders firmly grounded boots and true-surface contact drop-shadows,
 * provides rich road infrastructure including street lamps and the Dark Valley Tunnel portal.
 */
class GameRenderer {

    // --- High-Visibility Atmospheric Color Palette ---
    private val skyTopColor = Color(0xFF0F1826)
    private val skyMidColor = Color(0xFF1B2A3E)
    private val skyHorizonColor = Color(0xFF2B3E58)
    private val moonGlowInner = Color(0xFFE2EDFB)
    private val moonGlowOuter = Color(0x00E2EDFB)

    private val farMountainColor = Color(0xFF1C2B3C)
    private val farRidgeHighlight = Color(0xFF33465E)
    private val midgroundTreeColor = Color(0xFF233449)
    private val midgroundStructureColor = Color(0xFF28394F)

    private val roadAsphaltColor = Color(0xFF333E4D)
    private val roadCurbColor = Color(0xFF4C5B6E)
    private val roadCurbHighlight = Color(0xFF7A8FA6)
    private val roadLineYellow = Color(0xFFF5B025)
    private val roadLineWhite = Color(0xFFD6E3F2)

    private val platformBodyColor = Color(0xFF3A485A)
    private val platformEdgeHighlight = Color(0xFF869DB8)
    private val hazardYellow = Color(0xFFF59E0B)

    private val aliCoatColor = Color(0xFF222C3A)
    private val aliRimLight = Color(0xFF7B99BD)
    private val skinColor = Color(0xFFE8C9A8)

    private val walaaJacketColor = Color(0xFF234454)
    private val walaaScarfColor = Color(0xFF2DD4BF)
    private val walaaRimLight = Color(0xFF67B8CE)

    // Reusable pre-allocated Path objects to prevent 60fps GC allocations
    private val mountainPath = Path()
    private val factoryRoofPath = Path()
    private val carPath = Path()
    private val lightConePath = Path()
    private val aliTorsoPath = Path()
    private val walaaJacketPath = Path()
    private val beaconPath = Path()
    private val treeTierPath = Path()
    private val fogPath = Path()
    private val tunnelArchPath = Path()

    private var animationTick = 0f
    private var lastRenderTimeNanos = 0L

    fun render(
        drawScope: DrawScope,
        ali: Player,
        walaa: Player,
        activeCharacterId: CharacterId,
        world: World,
        camera: Camera2D,
        fogOffset: Float = 0f,
        monsterWorldX: Float = 2480f
    ) {
        // Preserve approximately the old animation speed at 60 FPS while making
        // it independent of the device refresh rate. Clamp long gaps (pause or
        // app backgrounding) so effects do not jump forward on resume.
        val nowNanos = System.nanoTime()
        if (lastRenderTimeNanos != 0L) {
            val elapsedSeconds = ((nowNanos - lastRenderTimeNanos).coerceAtLeast(0L) / 1_000_000_000f)
                .coerceIn(0f, 0.05f)
            animationTick += elapsedSeconds * 2.1f
        }
        lastRenderTimeNanos = nowNanos

        val w = drawScope.size.width
        val h = drawScope.size.height
        camera.updateViewport(w, h)

        // 1. Sky & Glowing Moon (Layer 0)
        drawSkyAndMoon(drawScope, w, h)

        // 2. Far Mountain Ridge (Layer 1, Parallax 0.12x)
        drawFarMountainRange(drawScope, camera, w, h)

        // 3. Midground Silhouettes (Layer 2, Parallax 0.38x)
        drawMidgroundInfrastructure(drawScope, world, camera, h)

        // 4. Near Roadside Scenery (Layer 3, Parallax 0.65x)
        drawRoadsideVegetationAndPoles(drawScope, world, camera)

        // 5. Gameplay Layer: Road and Platforms (Parallax 1.0x)
        drawHighwayAndPlatforms(drawScope, world, camera)

        // 6. Road Scenery Elements: Lamps, Signs, Billboard
        drawRoadSceneryElements(drawScope, world, camera)

        // 7. Puzzle Elements: Heavy Crate, Crawl Duct, Gate, Lever
        drawPuzzleInteractables(drawScope, world, camera)

        // 8. Broken Roadside Vehicle
        drawBrokenVehicle(drawScope, camera)

        // 9. Dark Valley Tunnel Entrance (Stage Checkpoint at 3200f - 3600f)
        drawTunnelPortal(drawScope, world, camera)

        // 10. Distant watcher: an original, low-contrast silhouette placed in the world.
        drawDistantWatcher(drawScope, camera, w, h, monsterWorldX)

        // 11. Both Characters with Firm Ground Contact & Contact Shadows
        if (activeCharacterId == CharacterId.ALI) {
            drawWalaa(drawScope, walaa, camera, isActive = false, world = world)
            drawAli(drawScope, ali, camera, isActive = true, world = world)
        } else {
            drawAli(drawScope, ali, camera, isActive = false, world = world)
            drawWalaa(drawScope, walaa, camera, isActive = true, world = world)
        }

        // 12. Light Ambient Mist
        drawAmbientFog(drawScope, w, h, fogOffset)

        // 13. Fine rain streaks and wet-road glints add motion to the playable scene.
        drawRainAndWetRoad(drawScope, w, h)

        // 14. Subtle Lens Framing (15% Max Edge Shading, No Blackout)
        drawCinematicFraming(drawScope, w, h)
    }

    private fun drawSkyAndMoon(drawScope: DrawScope, w: Float, h: Float) {
        drawScope.drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(skyTopColor, skyMidColor, skyHorizonColor),
                startY = 0f,
                endY = h * 0.85f
            ),
            size = Size(w, h)
        )

        val moonCenter = Offset(w * 0.72f, h * 0.22f)
        val moonRadius = 32f

        drawScope.drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x35B8D5FA), moonGlowOuter),
                center = moonCenter,
                radius = 140f
            ),
            radius = 140f,
            center = moonCenter
        )

        drawScope.drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(moonGlowInner, Color(0xFFC7DCF5)),
                center = moonCenter,
                radius = moonRadius
            ),
            radius = moonRadius,
            center = moonCenter
        )

        drawScope.drawOval(
            color = Color(0x281B2A3E),
            topLeft = Offset(moonCenter.x - 70f + sin(animationTick * 0.5f) * 15f, moonCenter.y - 10f),
            size = Size(140f, 24f)
        )
    }

    private fun drawFarMountainRange(drawScope: DrawScope, camera: Camera2D, screenW: Float, screenH: Float) {
        mountainPath.rewind()
        val baseY = screenH * 0.62f
        mountainPath.moveTo(0f, screenH)
        mountainPath.lineTo(0f, baseY)

        val step = 60f
        var currentX = 0f
        while (currentX <= screenW + step) {
            val worldX = currentX + (camera.position.x * 0.12f)
            val mountainHeight = sin(worldX * 0.0025f) * 75f + sin(worldX * 0.007f) * 35f + sin(worldX * 0.015f) * 15f
            mountainPath.lineTo(currentX, baseY - mountainHeight)
            currentX += step
        }
        mountainPath.lineTo(screenW, screenH)
        mountainPath.close()

        drawScope.drawPath(path = mountainPath, color = farMountainColor)

        val towerScreenX = (screenW * 0.35f) - (camera.position.x * 0.12f % screenW)
        if (towerScreenX > 0 && towerScreenX < screenW) {
            val towerBaseY = baseY - 60f
            drawScope.drawLine(
                color = farRidgeHighlight,
                start = Offset(towerScreenX, towerBaseY),
                end = Offset(towerScreenX, towerBaseY - 110f),
                strokeWidth = 3f
            )
            val beaconPulse = (sin(animationTick * 5f) > 0f)
            if (beaconPulse) {
                drawScope.drawCircle(
                    color = Color(0xFFFF3333),
                    radius = 4f,
                    center = Offset(towerScreenX, towerBaseY - 110f)
                )
            }
        }
    }

    private fun drawMidgroundInfrastructure(drawScope: DrawScope, world: World, camera: Camera2D, screenH: Float) {
        val parallax = 0.38f
        val factoryWorldX = 1400f
        val fsx = camera.worldToScreenX(factoryWorldX, parallax)
        val fsy = screenH * 0.65f
        if (fsx > -250f && fsx < camera.viewportWidth + 250f) {
            drawScope.drawRect(
                color = midgroundStructureColor,
                topLeft = Offset(fsx, fsy - 120f),
                size = Size(180f, 120f)
            )

            factoryRoofPath.rewind()
            factoryRoofPath.moveTo(fsx - 10f, fsy - 120f)
            factoryRoofPath.lineTo(fsx + 90f, fsy - 165f)
            factoryRoofPath.lineTo(fsx + 190f, fsy - 120f)
            factoryRoofPath.close()
            drawScope.drawPath(factoryRoofPath, midgroundStructureColor)

            drawScope.drawRect(
                color = midgroundStructureColor,
                topLeft = Offset(fsx + 130f, fsy - 200f),
                size = Size(22f, 80f)
            )
        }

        val treePoints = listOf(300f, 650f, 1050f, 1750f, 2200f, 2800f)
        for (tx in treePoints) {
            val sx = camera.worldToScreenX(tx, parallax)
            val sy = screenH * 0.66f
            if (sx > -80f && sx < camera.viewportWidth + 80f) {
                drawDetailedTree(drawScope, sx, sy, 0.75f, midgroundTreeColor)
            }
        }
    }

    private fun drawRoadsideVegetationAndPoles(drawScope: DrawScope, world: World, camera: Camera2D) {
        val parallax = 0.65f
        for (scenery in world.scenery.filter { it.parallaxLayer in 0.5f..0.8f }) {
            val sx = camera.worldToScreenX(scenery.x, parallax)
            val sy = camera.worldToScreenY(world.groundY, parallax)
            if (sx > -100f && sx < camera.viewportWidth + 100f) {
                drawDetailedTree(drawScope, sx, sy, 0.95f, Color(0xFF2A3D55))
            }
        }
    }

    private fun drawHighwayAndPlatforms(drawScope: DrawScope, world: World, camera: Camera2D) {
        for (platform in world.platforms) {
            val bounds = platform.bounds
            val sx = camera.worldToScreenX(bounds.left)
            val sy = camera.worldToScreenY(bounds.top)
            val sw = bounds.width
            val sh = bounds.height

            if (sx + sw < -60f || sx > camera.viewportWidth + 60f) continue

            if (platform.isGround) {
                drawScope.drawRect(
                    color = roadAsphaltColor,
                    topLeft = Offset(sx, sy),
                    size = Size(sw, sh)
                )

                drawScope.drawRect(
                    color = roadCurbColor,
                    topLeft = Offset(sx, sy),
                    size = Size(sw, 12f)
                )
                drawScope.drawRect(
                    color = roadCurbHighlight,
                    topLeft = Offset(sx, sy),
                    size = Size(sw, 3.5f)
                )

                drawScope.drawRect(
                    color = roadLineWhite,
                    topLeft = Offset(sx, sy + 18f),
                    size = Size(sw, 4f)
                )

                var lineX = bounds.left + 40f
                while (lineX < bounds.right) {
                    val markX = camera.worldToScreenX(lineX)
                    val markY = camera.worldToScreenY(bounds.top + 55f)
                    if (markX > -80f && markX < camera.viewportWidth + 80f) {
                        drawScope.drawRect(
                            color = roadLineYellow,
                            topLeft = Offset(markX, markY),
                            size = Size(65f, 7f)
                        )
                    }
                    lineX += 135f
                }
            } else {
                drawScope.drawRect(
                    color = platformBodyColor,
                    topLeft = Offset(sx, sy),
                    size = Size(sw, sh)
                )
                drawScope.drawRect(
                    color = platformEdgeHighlight,
                    topLeft = Offset(sx, sy),
                    size = Size(sw, 5f)
                )
                var stripeX = sx + 8f
                while (stripeX < sx + sw - 8f) {
                    drawScope.drawLine(
                        color = hazardYellow,
                        start = Offset(stripeX, sy + 6f),
                        end = Offset(stripeX + 10f, sy + sh - 2f),
                        strokeWidth = 3f
                    )
                    stripeX += 18f
                }
                val groundScreenY = camera.worldToScreenY(world.groundY)
                drawScope.drawRect(
                    color = Color(0xFF2B3747),
                    topLeft = Offset(sx + 25f, sy + sh),
                    size = Size(12f, groundScreenY - (sy + sh))
                )
                drawScope.drawRect(
                    color = Color(0xFF2B3747),
                    topLeft = Offset(sx + sw - 37f, sy + sh),
                    size = Size(12f, groundScreenY - (sy + sh))
                )
            }
        }
    }

    private fun drawRoadSceneryElements(drawScope: DrawScope, world: World, camera: Camera2D) {
        for (item in world.scenery.filter { it.parallaxLayer == 1.0f }) {
            val sx = camera.worldToScreenX(item.x)
            val sy = camera.worldToScreenY(world.groundY)
            if (sx < -100f || sx > camera.viewportWidth + 100f) continue

            when (item.type) {
                SceneryType.STREET_LAMP -> {
                    // Tall roadside lamp post
                    drawScope.drawLine(
                        color = Color(0xFF3B485A),
                        start = Offset(sx, sy),
                        end = Offset(sx, sy - 180f),
                        strokeWidth = 6f
                    )
                    drawScope.drawLine(
                        color = Color(0xFF3B485A),
                        start = Offset(sx, sy - 180f),
                        end = Offset(sx + 35f, sy - 195f),
                        strokeWidth = 5f
                    )
                    // Amber flickering lantern
                    val lampPulse = sin(animationTick * 4f) * 0.1f + 0.9f
                    drawScope.drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0x55F59E0B), Color(0x00F59E0B)),
                            center = Offset(sx + 35f, sy - 195f),
                            radius = 110f * lampPulse
                        ),
                        radius = 110f * lampPulse,
                        center = Offset(sx + 35f, sy - 195f)
                    )
                    drawScope.drawCircle(
                        color = Color(0xFFFBBF24),
                        radius = 7f,
                        center = Offset(sx + 35f, sy - 195f)
                    )
                }
                SceneryType.TELEPHONE_POLE -> {
                    drawScope.drawLine(
                        color = Color(0xFF2E3947),
                        start = Offset(sx, sy),
                        end = Offset(sx, sy - 210f),
                        strokeWidth = 8f
                    )
                    drawScope.drawLine(
                        color = Color(0xFF2E3947),
                        start = Offset(sx - 28f, sy - 190f),
                        end = Offset(sx + 28f, sy - 190f),
                        strokeWidth = 5f
                    )
                }
                SceneryType.FALLEN_BILLBOARD -> {
                    drawScope.drawRect(
                        color = Color(0xFF273240),
                        topLeft = Offset(sx, sy - 90f),
                        size = Size(140f, 90f)
                    )
                    drawScope.drawRect(
                        color = Color(0xFF435870),
                        topLeft = Offset(sx + 8f, sy - 82f),
                        size = Size(124f, 74f)
                    )
                    drawScope.drawLine(
                        color = Color(0xFFEF4444),
                        start = Offset(sx + 15f, sy - 45f),
                        end = Offset(sx + 125f, sy - 45f),
                        strokeWidth = 4f
                    )
                }
                SceneryType.BARRIER -> {
                    drawScope.drawRect(
                        color = Color(0xFF475569),
                        topLeft = Offset(sx, sy - 40f),
                        size = Size(70f, 40f)
                    )
                    drawScope.drawLine(
                        color = Color(0xFFF59E0B),
                        start = Offset(sx + 8f, sy - 20f),
                        end = Offset(sx + 62f, sy - 20f),
                        strokeWidth = 8f
                    )
                }
                SceneryType.ROAD_SIGN -> {
                    drawScope.drawLine(
                        color = Color(0xFF4C5D73),
                        start = Offset(sx, sy),
                        end = Offset(sx, sy - 85f),
                        strokeWidth = 4.5f
                    )
                    drawScope.drawCircle(
                        color = Color(0xFFDC2626),
                        radius = 16f,
                        center = Offset(sx, sy - 95f)
                    )
                    drawScope.drawCircle(
                        color = Color.White,
                        radius = 12f,
                        center = Offset(sx, sy - 95f)
                    )
                    drawScope.drawRect(
                        color = Color(0xFFDC2626),
                        topLeft = Offset(sx - 8f, sy - 98f),
                        size = Size(16f, 6f)
                    )
                }
                else -> {}
            }
        }
    }

    private fun drawPuzzleInteractables(drawScope: DrawScope, world: World, camera: Camera2D) {
        // A. Heavy Movable Steel Crate
        val crate = world.heavyCrate
        val cx = camera.worldToScreenX(crate.x)
        val cy = camera.worldToScreenY(crate.y - crate.height)
        if (cx + crate.width > -50f && cx < camera.viewportWidth + 50f) {
            val scratchStartX = camera.worldToScreenX(920f)
            val scratchEndX = camera.worldToScreenX(crate.targetSlotX + crate.width)
            drawScope.drawLine(
                color = Color(0xFF222933),
                start = Offset(scratchStartX, cy + crate.height - 2f),
                end = Offset(scratchEndX, cy + crate.height - 2f),
                strokeWidth = 4f
            )

            drawScope.drawRect(
                color = Color(0xFF45556B),
                topLeft = Offset(cx, cy),
                size = Size(crate.width, crate.height)
            )
            val bracketSize = 14f
            drawScope.drawRect(
                color = Color(0xFFD97706),
                topLeft = Offset(cx, cy),
                size = Size(bracketSize, bracketSize)
            )
            drawScope.drawRect(
                color = Color(0xFFD97706),
                topLeft = Offset(cx + crate.width - bracketSize, cy),
                size = Size(bracketSize, bracketSize)
            )
            drawScope.drawRect(
                color = Color(0xFFD97706),
                topLeft = Offset(cx, cy + crate.height - bracketSize),
                size = Size(bracketSize, bracketSize)
            )
            drawScope.drawRect(
                color = Color(0xFFD97706),
                topLeft = Offset(cx + crate.width - bracketSize, cy + crate.height - bracketSize),
                size = Size(bracketSize, bracketSize)
            )
            drawScope.drawLine(
                color = Color(0xFF6B83A4),
                start = Offset(cx + 6f, cy + 6f),
                end = Offset(cx + crate.width - 6f, cy + crate.height - 6f),
                strokeWidth = 3f
            )
            drawScope.drawLine(
                color = Color(0xFF6B83A4),
                start = Offset(cx + crate.width - 6f, cy + 6f),
                end = Offset(cx + 6f, cy + crate.height - 6f),
                strokeWidth = 3f
            )
            drawScope.drawRect(
                color = Color(0xFFFBBF24),
                topLeft = Offset(cx + 10f, cy + crate.height * 0.45f),
                size = Size(crate.width - 20f, 8f)
            )
        }

        // B. Narrow Low Crawl Duct on High Catwalk (Floor: 535f, Ceiling: 490f)
        val duct = world.narrowDuct
        val dx1 = camera.worldToScreenX(duct.left)
        val dx2 = camera.worldToScreenX(duct.right)
        val dFloorY = camera.worldToScreenY(duct.floorY)
        val dCeilY = camera.worldToScreenY(duct.ceilingY)
        if (dx2 > -50f && dx1 < camera.viewportWidth + 50f) {
            drawScope.drawRect(
                color = Color(0xFF222C3A),
                topLeft = Offset(dx1, dCeilY - 35f),
                size = Size(dx2 - dx1, 35f)
            )
            drawScope.drawRect(
                color = Color(0xFF5D7494),
                topLeft = Offset(dx1, dCeilY - 3f),
                size = Size(dx2 - dx1, 3f)
            )
            var stripeX = dx1
            while (stripeX < dx2) {
                drawScope.drawLine(
                    color = hazardYellow,
                    start = Offset(stripeX, dCeilY - 18f),
                    end = Offset(stripeX + 10f, dCeilY - 2f),
                    strokeWidth = 3.5f
                )
                stripeX += 16f
            }
            drawScope.drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0x66182230), Color(0x11182230)),
                    startY = dCeilY,
                    endY = dFloorY
                ),
                topLeft = Offset(dx1, dCeilY),
                size = Size(dx2 - dx1, dFloorY - dCeilY)
            )
        }

        // C. Security Roadblock Gate (from ground 700f up to catwalk 535f)
        val gate = world.securityGate
        val gx = camera.worldToScreenX(gate.x)
        val gy = camera.worldToScreenY(gate.groundY)
        val gHeight = gate.currentHeight
        if (gx > -50f && gx < camera.viewportWidth + 50f) {
            drawScope.drawRect(
                color = Color(0xFF4A5C73),
                topLeft = Offset(gx, gy - gHeight),
                size = Size(gate.width, gHeight)
            )
            drawScope.drawLine(
                color = Color(0xFFEF4444),
                start = Offset(gx, gy - gHeight + 14f),
                end = Offset(gx + gate.width, gy - gHeight + 14f),
                strokeWidth = 6f
            )
            drawScope.drawLine(
                color = Color(0xFFFFFFFF),
                start = Offset(gx, gy - gHeight + 32f),
                end = Offset(gx + gate.width, gy - gHeight + 32f),
                strokeWidth = 5f
            )
            // Power conduit cable connecting gate to switch
            val lx = camera.worldToScreenX(world.gateLever.x)
            val ly = camera.worldToScreenY(world.gateLever.y)
            drawScope.drawLine(
                color = if (gate.isOpen) Color(0xFF10B981) else Color(0xFF334155),
                start = Offset(gx + gate.width, gy - gHeight + 8f),
                end = Offset(lx, ly - 10f),
                strokeWidth = 2.5f
            )

            // Warning beacon on gate post
            val gateBeaconBlink = sin(animationTick * 6f) > 0f
            val gateLightColor = if (gate.isOpen) Color(0xFF22C55E) else (if (gateBeaconBlink) Color(0xFFEF4444) else Color(0xFF7F1D1D))
            drawScope.drawCircle(
                color = gateLightColor,
                radius = 7f,
                center = Offset(gx + gate.width / 2f, gy - gHeight - 10f)
            )
            drawScope.drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(gateLightColor.copy(alpha = 0.5f), Color.Transparent),
                    center = Offset(gx + gate.width / 2f, gy - gHeight - 10f),
                    radius = 24f
                ),
                radius = 24f,
                center = Offset(gx + gate.width / 2f, gy - gHeight - 10f)
            )
        }

        // D. Electrical Gate Lever on High Catwalk (1430f, 535f)
        val lever = world.gateLever
        val lx = camera.worldToScreenX(lever.x)
        val ly = camera.worldToScreenY(lever.y)
        if (lx > -40f && lx < camera.viewportWidth + 40f) {
            // Electrical box panel
            drawScope.drawRect(
                color = Color(0xFF2B3747),
                topLeft = Offset(lx - 14f, ly - 40f),
                size = Size(28f, 40f)
            )
            drawScope.drawRect(
                color = Color(0xFF475569),
                topLeft = Offset(lx - 12f, ly - 38f),
                size = Size(24f, 36f)
            )

            // Animated interactive prompt ring when unactivated and character is nearby
            if (!lever.isActivated) {
                val promptPulse = (sin(animationTick * 5f) * 0.5f + 0.5f)
                drawScope.drawCircle(
                    color = Color(0xFF22C55E).copy(alpha = 0.35f * promptPulse),
                    radius = 18f + (6f * promptPulse),
                    center = Offset(lx, ly - 20f)
                )
            }

            // Mechanical lever arm
            val leverAngleOffset = if (lever.isActivated) 14f else -10f
            drawScope.drawLine(
                color = Color(0xFFE2E8F0),
                start = Offset(lx, ly - 20f),
                end = Offset(lx + leverAngleOffset, ly - 36f),
                strokeWidth = 4.5f
            )
            // Lever knob
            drawScope.drawCircle(
                color = Color(0xFFF1F5F9),
                radius = 5.5f,
                center = Offset(lx + leverAngleOffset, ly - 36f)
            )

            // Status LED indicator lamp
            val statusLedColor = if (lever.isActivated) Color(0xFF22C55E) else Color(0xFFEF4444)
            drawScope.drawCircle(
                color = statusLedColor,
                radius = 4f,
                center = Offset(lx - 6f, ly - 30f)
            )
            drawScope.drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(statusLedColor.copy(alpha = 0.6f), Color.Transparent),
                    center = Offset(lx - 6f, ly - 30f),
                    radius = 15f
                ),
                radius = 15f,
                center = Offset(lx - 6f, ly - 30f)
            )
        }
    }

    private fun drawBrokenVehicle(drawScope: DrawScope, camera: Camera2D) {
        val carWorldX = 130f
        val carWorldY = 700f
        val sx = camera.worldToScreenX(carWorldX)
        val sy = camera.worldToScreenY(carWorldY)
        if (sx + 220f < -50f || sx > camera.viewportWidth + 50f) return

        carPath.rewind()
        carPath.moveTo(sx, sy)
        carPath.lineTo(sx + 200f, sy)
        carPath.lineTo(sx + 195f, sy - 30f)
        carPath.lineTo(sx + 160f, sy - 42f)
        carPath.lineTo(sx + 130f, sy - 74f)
        carPath.lineTo(sx + 45f, sy - 74f)
        carPath.lineTo(sx + 20f, sy - 38f)
        carPath.lineTo(sx, sy - 26f)
        carPath.close()

        drawScope.drawPath(carPath, Color(0xFF263345))
        drawScope.drawPath(carPath, Color(0xFF5D7699), style = Stroke(width = 2.5f))

        drawScope.drawRect(
            color = Color(0xFF5A789E),
            topLeft = Offset(sx + 55f, sy - 70f),
            size = Size(65f, 26f)
        )

        drawScope.drawCircle(Color(0xFF141C26), radius = 20f, center = Offset(sx + 40f, sy))
        drawScope.drawCircle(Color(0xFF6B85A6), radius = 8f, center = Offset(sx + 40f, sy))

        drawScope.drawCircle(Color(0xFF141C26), radius = 20f, center = Offset(sx + 160f, sy))
        drawScope.drawCircle(Color(0xFF6B85A6), radius = 8f, center = Offset(sx + 160f, sy))

        val steamY = (animationTick * 30f) % 45f
        drawScope.drawCircle(
            color = Color(0x33B8D4F5),
            radius = 14f,
            center = Offset(sx + 18f, sy - 45f - steamY)
        )

        val blink = (sin(animationTick * 6f) > 0f)
        if (blink) {
            drawScope.drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xCCF59E0B), Color(0x00F59E0B)),
                    center = Offset(sx + 195f, sy - 26f),
                    radius = 55f
                ),
                radius = 55f,
                center = Offset(sx + 195f, sy - 26f)
            )
            drawScope.drawCircle(
                color = Color(0xFFFBBF24),
                radius = 6f,
                center = Offset(sx + 195f, sy - 26f)
            )
        }
    }

    /**
     * Renders Dark Valley Tunnel Portal at the end of the stage (3200f - 3600f).
     * Prevents the stage from ending abruptly into an unfinished void.
     */
    private fun drawTunnelPortal(drawScope: DrawScope, world: World, camera: Camera2D) {
        val tunnelStartX = 3250f
        val tsx = camera.worldToScreenX(tunnelStartX)
        val tsy = camera.worldToScreenY(world.groundY)

        if (tsx > camera.viewportWidth + 100f || tsx + 400f < -100f) return

        // Massive concrete tunnel portal
        tunnelArchPath.rewind()
        tunnelArchPath.moveTo(tsx, tsy)
        tunnelArchPath.lineTo(tsx, tsy - 260f)
        tunnelArchPath.lineTo(tsx + 350f, tsy - 260f)
        tunnelArchPath.lineTo(tsx + 350f, tsy)
        tunnelArchPath.close()

        drawScope.drawPath(tunnelArchPath, Color(0xFF1A222D))

        // Cavernous inner dark portal entrance
        drawScope.drawRect(
            brush = Brush.horizontalGradient(
                colors = listOf(Color(0xFF070A0F), Color(0xFF030407)),
                startX = tsx + 40f,
                endX = tsx + 350f
            ),
            topLeft = Offset(tsx + 40f, tsy - 220f),
            size = Size(310f, 220f)
        )

        // Portal concrete frame highlight
        drawScope.drawRect(
            color = Color(0xFF47586E),
            topLeft = Offset(tsx, tsy - 260f),
            size = Size(350f, 20f)
        )

        // Warning Hazard Stripes across portal lintel
        var stripeX = tsx + 10f
        while (stripeX < tsx + 340f) {
            drawScope.drawLine(
                color = hazardYellow,
                start = Offset(stripeX, tsy - 258f),
                end = Offset(stripeX + 14f, tsy - 242f),
                strokeWidth = 4f
            )
            stripeX += 22f
        }

        // Tunnel Red Inspection Beacon
        val tunnelBlink = sin(animationTick * 5f) > 0f
        drawScope.drawCircle(
            color = if (tunnelBlink) Color(0xFFEF4444) else Color(0xFF991B1B),
            radius = 8f,
            center = Offset(tsx + 30f, tsy - 240f)
        )
        if (tunnelBlink) {
            drawScope.drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x66EF4444), Color.Transparent),
                    center = Offset(tsx + 30f, tsy - 240f),
                    radius = 45f
                ),
                radius = 45f,
                center = Offset(tsx + 30f, tsy - 240f)
            )
        }
    }

    /**
     * Renders Ali with firmly anchored boots and a realistic contact ground shadow.
     */
    private fun drawAli(drawScope: DrawScope, player: Player, camera: Camera2D, isActive: Boolean, world: World) {
        val px = camera.worldToScreenX(player.position.x)
        val py = camera.worldToScreenY(player.position.y)
        val dirSign = if (player.facingRight) 1f else -1f
        val isCrouch = player.isCrouching
        val h = player.currentHeight
        val w = player.width

        // --- Ground Contact Shadow on True Surface ---
        var surfaceY = world.groundY
        for (p in world.getActivePlatforms()) {
            if (player.position.x + player.width > p.bounds.left && player.position.x < p.bounds.right) {
                if (p.bounds.top >= player.position.y - 4f && p.bounds.top <= surfaceY) {
                    surfaceY = p.bounds.top
                }
            }
        }
        val shadowScreenY = camera.worldToScreenY(surfaceY)
        val jumpDist = (surfaceY - player.position.y).coerceAtLeast(0f)
        val shadowScale = (1f - (jumpDist / 220f)).coerceIn(0.25f, 1.0f)

        drawScope.drawOval(
            color = Color(0x66000000),
            topLeft = Offset(px + (w * 0.5f) - (20f * shadowScale), shadowScreenY - 3f),
            size = Size(40f * shadowScale, 6f * shadowScale)
        )

        // Active Beacon Overhead
        if (isActive) {
            val beaconY = py - h - 22f + sin(animationTick * 5f) * 3f
            drawActiveBeacon(drawScope, px + w / 2f, beaconY, Color(0xFFF5A623))
        }

        // Lantern Hand coordinates
        val lanternHandX = px + (w / 2f) + (dirSign * 18f)
        val lanternHandY = py - (h * 0.45f)

        // 360-degree ambient light pool
        drawScope.drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x55F5A623), Color(0x15F5A623), Color.Transparent),
                center = Offset(px + w / 2f, py - h * 0.4f),
                radius = 160f
            ),
            radius = 160f,
            center = Offset(px + w / 2f, py - h * 0.4f)
        )

        // Forward directional beam
        val beamRadius = 260f
        val coneSpread = 160f
        val coneTargetX = lanternHandX + (dirSign * beamRadius)
        val coneTargetY = lanternHandY + 25f

        lightConePath.rewind()
        lightConePath.moveTo(lanternHandX, lanternHandY)
        lightConePath.lineTo(coneTargetX, coneTargetY - coneSpread)
        lightConePath.lineTo(coneTargetX, coneTargetY + coneSpread)
        lightConePath.close()

        drawScope.drawPath(
            path = lightConePath,
            brush = Brush.radialGradient(
                colors = listOf(Color(0x40F5A623), Color(0x00F5A623)),
                center = Offset(lanternHandX, lanternHandY),
                radius = beamRadius * 1.1f
            )
        )

        drawScope.drawCircle(
            color = Color(0xFFFBBF24),
            radius = 6f,
            center = Offset(lanternHandX, lanternHandY)
        )

        // Stride offset
        val legOffset = if (player.state == MovementState.WALKING || player.state == MovementState.RUNNING || player.state == MovementState.PUSHING) {
            sin(animationTick * if (player.isRunning) 9f else 6f) * 9f
        } else 0f

        // Legs (dark trousers) ending firmly at py (road surface)
        val backFootX = px + (w * 0.5f) - legOffset
        val frontFootX = px + (w * 0.5f) + legOffset

        drawScope.drawLine(
            color = Color(0xFF1B2330),
            start = Offset(px + (w * 0.5f), py - (h * 0.42f)),
            end = Offset(backFootX, py),
            strokeWidth = 7f
        )
        drawScope.drawLine(
            color = aliCoatColor,
            start = Offset(px + (w * 0.5f), py - (h * 0.42f)),
            end = Offset(frontFootX, py),
            strokeWidth = 7f
        )

        // Boots firmly planted on the surface (resolves floating appearance)
        drawScope.drawLine(
            color = Color(0xFF0F141C),
            start = Offset(backFootX - (if (player.facingRight) 3f else 9f), py),
            end = Offset(backFootX + (if (player.facingRight) 9f else 3f), py),
            strokeWidth = 5f
        )
        drawScope.drawLine(
            color = Color(0xFF0F141C),
            start = Offset(frontFootX - (if (player.facingRight) 3f else 9f), py),
            end = Offset(frontFootX + (if (player.facingRight) 9f else 3f), py),
            strokeWidth = 5f
        )

        // Shoulder and arm motion makes the procedural character feel less rigid.
        // Movement uses a deterministic gait phase; idle uses a subtle breathing sway.
        val aliMoving = player.state == MovementState.WALKING || player.state == MovementState.RUNNING || player.state == MovementState.PUSHING
        val aliArmSwing = if (aliMoving) sin(animationTick * if (player.isRunning) 9f else 6f) * 7f else sin(animationTick * 1.7f) * 1.2f
        val aliShoulder = Offset(px + w * 0.52f, py - h * 0.60f)
        drawScope.drawLine(
            color = Color(0xFF1B2430),
            start = aliShoulder,
            end = Offset(aliShoulder.x + dirSign * 8f + aliArmSwing, aliShoulder.y + h * 0.19f),
            strokeWidth = 5.5f
        )
        drawScope.drawLine(
            color = Color(0xFF53657A),
            start = Offset(aliShoulder.x + dirSign * 8f + aliArmSwing, aliShoulder.y + h * 0.19f),
            end = Offset(aliShoulder.x + dirSign * 13f + aliArmSwing, aliShoulder.y + h * 0.26f),
            strokeWidth = 3.5f
        )

        // Torso / Trenchcoat
        aliTorsoPath.rewind()
        aliTorsoPath.moveTo(px + (w * 0.2f), py - (h * 0.72f))
        aliTorsoPath.lineTo(px + (w * 0.8f), py - (h * 0.72f))
        aliTorsoPath.lineTo(px + (w * 0.9f) + (dirSign * 4f), py - (h * 0.25f))
        aliTorsoPath.lineTo(px + (w * 0.1f) - (dirSign * 6f), py - (h * 0.25f))
        aliTorsoPath.close()

        drawScope.drawPath(aliTorsoPath, color = aliCoatColor)
        drawScope.drawPath(aliTorsoPath, color = aliRimLight, style = Stroke(width = 2f))

        // Backpack silhouette and straps give Ali a readable survival-adventure profile.
        val packX = if (dirSign > 0f) px + w * 0.05f else px + w * 0.55f
        drawScope.drawRoundRect(
            color = Color(0xFF111A25),
            topLeft = Offset(packX, py - h * 0.70f),
            size = Size(w * 0.32f, h * 0.38f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(7f, 7f)
        )
        drawScope.drawLine(
            color = Color(0xFF58677A),
            start = Offset(px + w * 0.28f, py - h * 0.70f),
            end = Offset(px + w * 0.40f, py - h * 0.30f),
            strokeWidth = 2.2f
        )
        drawScope.drawLine(
            color = Color(0xFF526176),
            start = Offset(px + w * 0.48f, py - h * 0.57f),
            end = Offset(px + w * 0.73f, py - h * 0.49f),
            strokeWidth = 1.5f
        )
        drawScope.drawLine(
            color = Color(0xFF526176),
            start = Offset(px + w * 0.25f, py - h * 0.42f),
            end = Offset(px + w * 0.75f, py - h * 0.42f),
            strokeWidth = 1.3f
        )

        // Head & Collar
        val headRadius = if (isCrouch) 10f else 13f
        val headCenterY = py - (h * 0.84f)
        drawScope.drawCircle(
            color = skinColor,
            radius = headRadius,
            center = Offset(px + (w * 0.5f) + (dirSign * 2f), headCenterY)
        )
        drawScope.drawArc(
            color = Color(0xFF151B24),
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = true,
            topLeft = Offset(px + (w * 0.5f) - headRadius + (dirSign * 2f), headCenterY - headRadius),
            size = Size(headRadius * 2f, headRadius * 2f)
        )
        // Small face profile details catch the lantern light without heavy rendering cost.
        drawScope.drawLine(
            color = Color(0xFF5B463A),
            start = Offset(px + w * 0.5f + dirSign * 5f, headCenterY + 1f),
            end = Offset(px + w * 0.5f + dirSign * 10f, headCenterY + 2.5f),
            strokeWidth = 1.5f
        )
        drawScope.drawCircle(
            color = Color(0xFF17202B),
            radius = 1.5f,
            center = Offset(px + w * 0.5f + dirSign * 4f, headCenterY - 1f)
        )
        drawScope.drawLine(
            color = Color(0xFF53647A),
            start = Offset(px + w * 0.23f, py - h * 0.62f),
            end = Offset(px + w * 0.75f, py - h * 0.32f),
            strokeWidth = 1.4f
        )

        // Lantern cage
        drawScope.drawRect(
            color = Color(0xFF382F24),
            topLeft = Offset(lanternHandX - 4f, lanternHandY - 6f),
            size = Size(8f, 13f)
        )
    }

    /**
     * Renders Walaa with grounded footwear and contact drop-shadow.
     */
    private fun drawWalaa(drawScope: DrawScope, player: Player, camera: Camera2D, isActive: Boolean, world: World) {
        val px = camera.worldToScreenX(player.position.x)
        val py = camera.worldToScreenY(player.position.y)
        val dirSign = if (player.facingRight) 1f else -1f
        val isCrawl = player.state == MovementState.CRAWLING || (player.isCrouching && player.position.y <= 580f)
        val h = player.currentHeight
        val w = player.width

        // --- Ground Contact Shadow on True Surface ---
        var surfaceY = world.groundY
        for (p in world.getActivePlatforms()) {
            if (player.position.x + player.width > p.bounds.left && player.position.x < p.bounds.right) {
                if (p.bounds.top >= player.position.y - 4f && p.bounds.top <= surfaceY) {
                    surfaceY = p.bounds.top
                }
            }
        }
        val shadowScreenY = camera.worldToScreenY(surfaceY)
        val jumpDist = (surfaceY - player.position.y).coerceAtLeast(0f)
        val shadowScale = (1f - (jumpDist / 220f)).coerceIn(0.25f, 1.0f)

        drawScope.drawOval(
            color = Color(0x66000000),
            topLeft = Offset(px + (w * 0.5f) - (18f * shadowScale), shadowScreenY - 3f),
            size = Size(36f * shadowScale, 5.5f * shadowScale)
        )

        // Active Beacon Overhead
        if (isActive) {
            val beaconY = py - h - 22f + sin(animationTick * 5f) * 3f
            drawActiveBeacon(drawScope, px + w / 2f, beaconY, Color(0xFF2DD4BF))
        }

        // Ambient halo around Walaa
        drawScope.drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x352DD4BF), Color.Transparent),
                center = Offset(px + w / 2f, py - h * 0.4f),
                radius = 120f
            ),
            radius = 120f,
            center = Offset(px + w / 2f, py - h * 0.4f)
        )

        if (isCrawl) {
            val crawlY = py - 16f
            drawScope.drawOval(
                color = walaaJacketColor,
                topLeft = Offset(px, crawlY - 14f),
                size = Size(w + 16f, 22f)
            )
            drawScope.drawCircle(
                color = skinColor,
                radius = 9f,
                center = Offset(px + (if (dirSign > 0) w + 12f else 4f), crawlY - 4f)
            )
            drawScope.drawCircle(
                color = walaaScarfColor,
                radius = 5f,
                center = Offset(px + (if (dirSign > 0) w + 4f else 12f), crawlY)
            )
            return
        }

        val legOffset = if (player.state == MovementState.WALKING || player.state == MovementState.RUNNING) {
            sin(animationTick * if (player.isRunning) 10f else 7f) * 8f
        } else 0f

        val backFootX = px + (w * 0.5f) - legOffset
        val frontFootX = px + (w * 0.5f) + legOffset

        // Legs ending firmly at py
        drawScope.drawLine(
            color = Color(0xFF162330),
            start = Offset(px + (w * 0.5f), py - (h * 0.45f)),
            end = Offset(backFootX, py),
            strokeWidth = 6.5f
        )
        drawScope.drawLine(
            color = Color(0xFF203245),
            start = Offset(px + (w * 0.5f), py - (h * 0.45f)),
            end = Offset(frontFootX, py),
            strokeWidth = 6.5f
        )

        // Walaa's shoes planted firmly on the surface
        drawScope.drawLine(
            color = Color(0xFF121B24),
            start = Offset(backFootX - (if (player.facingRight) 2f else 7f), py),
            end = Offset(backFootX + (if (player.facingRight) 7f else 2f), py),
            strokeWidth = 4.5f
        )
        drawScope.drawLine(
            color = Color(0xFF121B24),
            start = Offset(frontFootX - (if (player.facingRight) 2f else 7f), py),
            end = Offset(frontFootX + (if (player.facingRight) 7f else 2f), py),
            strokeWidth = 4.5f
        )

        // Walaa's arm sway follows her gait while idle breathing stays restrained.
        val walaaMoving = player.state == MovementState.WALKING || player.state == MovementState.RUNNING
        val walaaArmSwing = if (walaaMoving) sin(animationTick * if (player.isRunning) 10f else 7f) * 6f else sin(animationTick * 1.6f) * 1.1f
        val walaaShoulder = Offset(px + w * 0.51f, py - h * 0.60f)
        drawScope.drawLine(
            color = Color(0xFF1A3441),
            start = walaaShoulder,
            end = Offset(walaaShoulder.x + dirSign * 6f + walaaArmSwing, walaaShoulder.y + h * 0.18f),
            strokeWidth = 5f
        )
        drawScope.drawLine(
            color = Color(0xFF5B8594),
            start = Offset(walaaShoulder.x + dirSign * 6f + walaaArmSwing, walaaShoulder.y + h * 0.18f),
            end = Offset(walaaShoulder.x + dirSign * 10f + walaaArmSwing, walaaShoulder.y + h * 0.25f),
            strokeWidth = 3f
        )

        // Hooded Athletic Jacket
        walaaJacketPath.rewind()
        walaaJacketPath.moveTo(px + (w * 0.25f), py - (h * 0.74f))
        walaaJacketPath.lineTo(px + (w * 0.75f), py - (h * 0.74f))
        walaaJacketPath.lineTo(px + (w * 0.85f) + (dirSign * 2f), py - (h * 0.35f))
        walaaJacketPath.lineTo(px + (w * 0.15f) - (dirSign * 2f), py - (h * 0.35f))
        walaaJacketPath.close()

        drawScope.drawPath(walaaJacketPath, color = walaaJacketColor)
        drawScope.drawPath(walaaJacketPath, color = walaaRimLight, style = Stroke(width = 2f))

        // Backpack, shoulder straps and jacket seams add depth to Walaa's silhouette.
        val walaaPackX = if (dirSign > 0f) px + w * 0.02f else px + w * 0.58f
        drawScope.drawRoundRect(
            color = Color(0xFF111C27),
            topLeft = Offset(walaaPackX, py - h * 0.70f),
            size = Size(w * 0.30f, h * 0.34f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
        )
        drawScope.drawLine(
            color = Color(0xFF587080),
            start = Offset(px + w * 0.27f, py - h * 0.70f),
            end = Offset(px + w * 0.39f, py - h * 0.35f),
            strokeWidth = 2f
        )
        drawScope.drawLine(
            color = Color(0xFF6D929E),
            start = Offset(px + w * 0.28f, py - h * 0.48f),
            end = Offset(px + w * 0.72f, py - h * 0.44f),
            strokeWidth = 1.2f
        )
        drawScope.drawLine(
            color = Color(0xFF142B37),
            start = Offset(px + w * 0.50f, py - h * 0.68f),
            end = Offset(px + w * 0.50f, py - h * 0.38f),
            strokeWidth = 1.5f
        )

        // Vibrant Aqua Scarf Band
        drawScope.drawRect(
            color = walaaScarfColor,
            topLeft = Offset(px + (w * 0.2f), py - (h * 0.76f)),
            size = Size(w * 0.6f, 6f)
        )

        // Head & Hood
        val headRadius = 11f
        val headCenterY = py - (h * 0.86f)
        drawScope.drawCircle(
            color = skinColor,
            radius = headRadius,
            center = Offset(px + (w * 0.5f), headCenterY)
        )
        drawScope.drawArc(
            color = Color(0xFF172631),
            startAngle = 160f,
            sweepAngle = 220f,
            useCenter = true,
            topLeft = Offset(px + (w * 0.5f) - headRadius - 1f, headCenterY - headRadius - 1f),
            size = Size((headRadius + 1f) * 2f, (headRadius + 1f) * 2f)
        )
        drawScope.drawCircle(
            color = Color(0xFF263E4A),
            radius = 3f,
            center = Offset(px + w * 0.5f - dirSign * 7f, headCenterY - 7f)
        )
        drawScope.drawLine(
            color = Color(0xFF6A4A40),
            start = Offset(px + w * 0.5f + dirSign * 4f, headCenterY + 1f),
            end = Offset(px + w * 0.5f + dirSign * 8f, headCenterY + 2f),
            strokeWidth = 1.2f
        )
    }

    private fun drawActiveBeacon(drawScope: DrawScope, cx: Float, cy: Float, color: Color) {
        beaconPath.rewind()
        beaconPath.moveTo(cx, cy - 8f)
        beaconPath.lineTo(cx + 7f, cy)
        beaconPath.lineTo(cx, cy + 8f)
        beaconPath.lineTo(cx - 7f, cy)
        beaconPath.close()
        drawScope.drawPath(beaconPath, color)
    }

    private fun drawDetailedTree(drawScope: DrawScope, sx: Float, sy: Float, scale: Float, color: Color) {
        val trunkH = 170f * scale
        drawScope.drawLine(
            color = color,
            start = Offset(sx, sy),
            end = Offset(sx, sy - trunkH),
            strokeWidth = 9f * scale
        )
        var tierY = sy - trunkH * 0.4f
        var tierW = 55f * scale
        while (tierY > sy - trunkH) {
            treeTierPath.rewind()
            treeTierPath.moveTo(sx, tierY - 25f * scale)
            treeTierPath.lineTo(sx + tierW, tierY)
            treeTierPath.lineTo(sx - tierW, tierY)
            treeTierPath.close()
            drawScope.drawPath(treeTierPath, color)
            tierY -= 30f * scale
            tierW *= 0.75f
        }
    }

    private fun drawAmbientFog(drawScope: DrawScope, w: Float, h: Float, fogOffset: Float) {
        val fogY = h * 0.66f
        fogPath.rewind()
        fogPath.moveTo(0f, fogY)
        var fx = 0f
        while (fx <= w + 60f) {
            val wave = sin((fx + fogOffset) * 0.006f) * 14f + sin((fx - fogOffset * 0.5f) * 0.012f) * 8f
            fogPath.lineTo(fx, fogY + wave)
            fx += 50f
        }
        fogPath.lineTo(w, h)
        fogPath.lineTo(0f, h)
        fogPath.close()

        drawScope.drawPath(
            path = fogPath,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0x184B6685), Color(0x061E2D3F)),
                startY = fogY - 20f,
                endY = h
            )
        )
    }


    /**
     * Subtle animated weather pass for gameplay. Deterministic screen-space streaks
     * avoid random allocations each frame and keep the renderer lightweight on Android.
     */
    private fun drawRainAndWetRoad(drawScope: DrawScope, w: Float, h: Float) {
        val rainColor = Color(0x337DA3C8)
        val streakCount = (w / 22f).toInt().coerceIn(18, 70)
        for (i in 0 until streakCount) {
            val baseX = (i * 73.17f + (animationTick * (85f + (i % 4) * 13f))) % (w + 30f)
            val baseY = (i * 47.31f + (animationTick * (150f + (i % 5) * 17f))) % (h * 0.78f)
            drawScope.drawLine(
                color = rainColor,
                start = Offset(baseX, baseY),
                end = Offset(baseX - 5f, baseY + 13f),
                strokeWidth = if (i % 5 == 0) 1.4f else 0.8f
            )
        }

        // A few nearer drops have a slightly brighter, thicker streak to create depth.
        for (i in 0 until 8) {
            val x = (i * 131.7f - animationTick * (125f + i * 4f)).let { ((it % (w + 40f)) + (w + 40f)) % (w + 40f) }
            val y = (i * 83.3f + animationTick * (190f + i * 9f)) % (h * 0.72f)
            drawScope.drawLine(
                color = Color(0x477DA3C8),
                start = Offset(x, y),
                end = Offset(x - 7f, y + 20f),
                strokeWidth = 1.25f
            )
        }

        // Broken reflections across the road surface; deliberately sparse, not a flat stripe.
        val roadY = h * 0.76f
        for (i in 0..10) {
            val x = (i * (w / 10.5f) + sin(animationTick * 0.7f + i) * 16f)
            val length = 8f + ((i * 7) % 19)
            val alpha = 0x12 + ((sin(animationTick * 1.2f + i * 0.8f) + 1f) * 8f).toInt()
            drawScope.drawLine(
                color = Color(0xFF9EB9D4).copy(alpha = alpha.coerceIn(8, 30) / 255f),
                start = Offset(x, roadY + (i % 3) * 8f),
                end = Offset(x + length, roadY + (i % 3) * 8f + 1f),
                strokeWidth = if (i % 3 == 0) 2f else 1f
            )
        }
    }


    /**
     * Original creature silhouette. Its horizontal world position is driven by the gameplay AI.
     */
    private fun drawDistantWatcher(drawScope: DrawScope, camera: Camera2D, w: Float, h: Float, worldX: Float) {
        val x = camera.worldToScreenX(worldX, 0.38f)
        if (x < -100f || x > w + 100f) return

        val ground = h * 0.59f + sin(animationTick * 0.7f) * 2.5f
        val body = Color(0xFF0A1119).copy(alpha = 0.82f)
        val rim = Color(0xFF263C50).copy(alpha = 0.68f)
        // Soft ground haze makes the creature sit behind the road-side scenery.
        drawScope.drawOval(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x302D5B78), Color.Transparent),
                center = Offset(x, ground + 10f),
                radius = 68f
            ),
            topLeft = Offset(x - 68f, ground - 15f),
            size = Size(136f, 50f)
        )
        // Long, hunched torso and head.
        drawScope.drawOval(color = body, topLeft = Offset(x - 19f, ground - 100f), size = Size(38f, 78f))
        drawScope.drawCircle(color = body, radius = 15f, center = Offset(x + 4f, ground - 111f))
        // Uneven, unnaturally long arms.
        drawScope.drawLine(rim, Offset(x - 12f, ground - 80f), Offset(x - 32f, ground - 43f), 7f)
        drawScope.drawLine(body, Offset(x - 32f, ground - 43f), Offset(x - 38f, ground - 22f), 4f)
        drawScope.drawLine(rim, Offset(x + 13f, ground - 81f), Offset(x + 31f, ground - 49f), 7f)
        drawScope.drawLine(body, Offset(x + 31f, ground - 49f), Offset(x + 36f, ground - 28f), 4f)
        // Bent legs.
        drawScope.drawLine(body, Offset(x - 9f, ground - 34f), Offset(x - 18f, ground - 5f), 8f)
        drawScope.drawLine(body, Offset(x + 9f, ground - 34f), Offset(x + 20f, ground - 5f), 8f)
        // Eyes pulse faintly, not brightly enough to spoil the dark atmosphere.
        val pulse = (0.25f + ((sin(animationTick * 1.4f) + 1f) * 0.18f)).coerceIn(0.2f, 0.65f)
        drawScope.drawCircle(Color(0xFF8FCBEA).copy(alpha = pulse), 2.4f, Offset(x + 8f, ground - 114f))
    }

    private fun drawCinematicFraming(drawScope: DrawScope, w: Float, h: Float) {
        drawScope.drawRect(
            brush = Brush.radialGradient(
                colors = listOf(Color.Transparent, Color(0x10000000), Color(0x28000000)),
                center = Offset(w / 2f, h / 2f),
                radius = w * 0.75f
            ),
            size = Size(w, h)
        )
    }
}
