package com.example.game.model

/**
 * 2D Vector representation for positions, velocities, and dimensions.
 */
data class Vector2(
    var x: Float = 0f,
    var y: Float = 0f
) {
    fun set(newX: Float, newY: Float) {
        x = newX
        y = newY
    }

    fun add(dx: Float, dy: Float) {
        x += dx
        y += dy
    }
}

/**
 * Axis-Aligned Bounding Box (AABB) for collision detection.
 */
data class Rect(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top

    fun intersects(other: Rect): Boolean {
        return left < other.right && right > other.left && top < other.bottom && bottom > other.top
    }
}
