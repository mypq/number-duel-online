package com.example.game.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.game.core.GameEngine
import com.example.game.core.GameScreenState
import com.example.game.render.GameRenderer

/**
 * Root Game Composable routing between Main Menu, Settings, and active 2.5D Gameplay.
 */
@Composable
fun GameScreen(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val engine = remember { GameEngine(context) }
    val renderer = remember { GameRenderer() }

    // Handle system back navigation
    BackHandler(enabled = true) {
        when (engine.screenState) {
            GameScreenState.SETTINGS -> engine.navigateToMainMenu()
            GameScreenState.PLAYING -> {
                if (engine.isPaused) {
                    engine.setPauseState(false)
                } else {
                    engine.setPauseState(true)
                }
            }
            GameScreenState.MAIN_MENU -> {
                // System default handles closing activity
            }
        }
    }

    when (engine.screenState) {
        GameScreenState.MAIN_MENU -> {
            MainMenuScreen(engine = engine, modifier = modifier)
        }
        GameScreenState.SETTINGS -> {
            SettingsScreen(engine = engine, modifier = modifier)
        }
        GameScreenState.PLAYING -> {
            // Active 60-120fps Game Loop
            LaunchedEffect(engine.screenState) {
                var lastTimeNanos = 0L
                while (engine.screenState == GameScreenState.PLAYING) {
                    withFrameNanos { frameTimeNanos ->
                        if (lastTimeNanos != 0L) {
                            val dt = (frameTimeNanos - lastTimeNanos) / 1_000_000_000f
                            engine.tick(dt)
                        }
                        lastTimeNanos = frameTimeNanos
                    }
                }
            }

            Box(
                modifier = modifier
                    .fillMaxSize()
                    .background(Color(0xFF04060A))
            ) {
                // 1. Hardware Accelerated Game Canvas (Draw phase isolated from recomposition)
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("game_canvas")
                ) {
                    val frameTick = engine.renderFrame // Read exclusively inside DrawScope
                    renderer.render(
                        drawScope = this,
                        ali = engine.ali,
                        walaa = engine.walaa,
                        activeCharacterId = engine.activeCharacterId,
                        world = engine.world,
                        camera = engine.camera,
                        fogOffset = engine.fogOffset,
                        monsterWorldX = engine.monsterWorldX
                    )
                }

                // 2. Mobile Touch Gamepad Controls Overlay
                TouchControls(
                    engine = engine,
                    modifier = Modifier.fillMaxSize()
                )

                // 3. Pause Modal Dialog
                if (engine.isPaused) {
                    PauseMenuDialog(
                        onResume = { engine.setPauseState(false) },
                        onRestart = { engine.startNewGame() },
                        onMainMenu = { engine.navigateToMainMenu() }
                    )
                }
            }
        }
    }
}

/**
 * Cinematic Pause Menu in Arabic.
 */
@Composable
fun PauseMenuDialog(
    onResume: () -> Unit,
    onRestart: () -> Unit,
    onMainMenu: () -> Unit
) {
    Dialog(onDismissRequest = onResume) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color(0xF20E131C),
            modifier = Modifier
                .width(360.dp)
                .border(1.5.dp, Color(0xFF38465B), RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "الطريق الأخير",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFEAF1FC),
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "The Last Road — إيقاف مؤقت",
                    fontSize = 13.sp,
                    color = Color(0xFF90A3BE),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
                )

                // Resume Button
                Button(
                    onClick = onResume,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFB56525),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_resume")
                ) {
                    Text(
                        text = "متابعة اللعب (Resume)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Restart Button
                OutlinedButton(
                    onClick = onRestart,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("btn_restart")
                ) {
                    Text(
                        text = "إعادة من البداية (Restart)",
                        color = Color(0xFFB5C8DF),
                        fontSize = 14.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Main Menu Button
                OutlinedButton(
                    onClick = onMainMenu,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("btn_pause_main_menu")
                ) {
                    Text(
                        text = "القائمة الرئيسية (Main Menu)",
                        color = Color(0xFF8BA0B8),
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}
