# The Last Road — performance fixes applied

This patch makes focused changes while preserving the existing game design and level data.

## Changes

1. `GameEngine.kt`: jump presses are queued while gameplay is active even when the player is airborne. `PhysicsSystem` now decides eligibility using the existing jump buffer, grounded state, coyote time, crouch and duct restrictions.
2. `PhysicsSystem.kt`: physics updates are split into enough sub-steps that each step is at most approximately 1/60 second, capped at three steps for the existing 50ms maximum delta.
3. `World.kt`: active platform list is reused instead of allocating a new combined list on every query. The crate-top platform is replaced only when the crate position changes.
4. `GameRenderer.kt`: ambient animation time is based on elapsed monotonic time rather than a fixed increment per render call, preserving approximately the previous speed at 60 FPS and clamping large render gaps.

## Validation limits

The ZIP was checked for archive integrity and source edits were reviewed. A Gradle build and Android device/runtime performance test could not be run in this environment because the supplied archive has no `gradlew` script or wrapper JAR, and no Gradle installation / Android SDK is available here. Please build and test on Android Studio or Google AI Studio before replacing your working copy.
