# The Last Road — الطريق الأخير

Native Android horror-adventure prototype built with Kotlin, Jetpack Compose, and a custom Canvas renderer.

## Open the project

Open this folder in Android Studio and let Gradle sync. The exported archive currently does not include `gradlew`, `gradlew.bat`, or `gradle-wrapper.jar`; use an installed Gradle/Android Studio setup to restore or generate the Gradle wrapper if required by your environment.

## Current state

The current project includes a main menu, settings, a procedural side-scrolling scene, movement/physics, camera follow, two character states, an initial crate/gate puzzle, and checkpoint persistence. It is still a prototype and does not yet include a finished original character/monster asset set or a complete tested chapter.

See [PROJECT_STATUS.md](PROJECT_STATUS.md) for the current development stage, actual checks performed, limitations, and next steps.

## Android build

Prerequisites: Android Studio and a compatible Android SDK. Full Android Gradle build and device testing were not available in the current editing environment, so build the project locally before installing it on a device.
